var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Design ---
var toolHTML = `
<style>
    .tm-box { background: #fff; padding: 15px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    
    textarea { 
        width: 100%; height: 200px; padding: 10px; border: 1px solid #ccc; 
        border-radius: 4px; font-family: monospace; font-size: 13px; 
        resize: vertical; box-sizing: border-box; 
    }
    
    .stats-bar {
        display: flex; justify-content: space-between; background: #e9ecef; 
        padding: 5px 10px; border-radius: 4px; margin-bottom: 10px; font-size: 12px; font-weight: bold; color: #555;
    }

    .control-group { border: 1px solid #eee; padding: 10px; border-radius: 5px; margin-bottom: 10px; text-align: left; }
    .group-title { font-size: 12px; font-weight: bold; color: #007bff; margin-bottom: 5px; text-transform: uppercase; }
    
    .btn-row { display: flex; gap: 5px; flex-wrap: wrap; margin-bottom: 5px; }
    
    input[type="text"], input[type="number"] {
        padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1; min-width: 80px;
    }

    button { padding: 8px 12px; border: none; border-radius: 4px; cursor: pointer; font-size: 13px; color: white; flex: 1; }
    
    .btn-blue { background: #007bff; }
    .btn-green { background: #28a745; }
    .btn-orange { background: #fd7e14; }
    .btn-red { background: #dc3545; }
    .btn-dark { background: #343a40; }
    .btn-warning { background: #ffc107; color: #333; }

    button:hover { opacity: 0.9; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>Text Master Tool</h1>
    
    <div class="tm-box">
        
        <!-- Import Section (New) -->
        <div class="btn-row">
            <input type="file" id="fileImport" style="display:none" onchange="importFile(this)">
            <button class="btn-warning" onclick="document.getElementById('fileImport').click()">📂 Open Text File</button>
            <button class="btn-dark" onclick="copyText()">📋 Copy</button>
            <button class="btn-red" onclick="clearText()">🗑 Clear</button>
        </div>

        <!-- Main Text Area -->
        <div class="stats-bar">
            <span id="charCount">Chars: 0</span>
            <span id="wordCount">Words: 0</span>
        </div>
        <textarea id="mainText" placeholder="Type here or Open a file to load content..." oninput="updateStats()"></textarea>

        <br>

        <!-- 1. Quick Transforms -->
        <div class="control-group">
            <div class="group-title">Quick Actions</div>
            <div class="btn-row">
                <button class="btn-blue" onclick="transform('upper')">UPPER</button>
                <button class="btn-blue" onclick="transform('lower')">lower</button>
                <button class="btn-blue" onclick="transform('title')">Title Case</button>
                <button class="btn-blue" onclick="transform('reverse')">Reverse</button>
                <button class="btn-blue" onclick="transform('clean')">Clean Space</button>
            </div>
        </div>

        <!-- 2. Find & Replace -->
        <div class="control-group">
            <div class="group-title">Find & Replace</div>
            <div class="btn-row">
                <input type="text" id="findTxt" placeholder="Find...">
                <input type="text" id="repTxt" placeholder="Replace with...">
                <button class="btn-orange" style="flex:0 auto;" onclick="replaceText()">Replace All</button>
            </div>
        </div>

        <!-- 3. Repeater -->
        <div class="control-group">
            <div class="group-title">Text Repeater</div>
            <div class="btn-row">
                <input type="number" id="repCount" placeholder="Times (e.g. 100)">
                <label style="display:flex; align-items:center; gap:5px; font-size:12px;">
                    <input type="checkbox" id="newLineCheck" checked> New Line
                </label>
                <button class="btn-orange" onclick="repeatText()">Repeat</button>
            </div>
        </div>

        <!-- 4. Export / Download -->
        <div class="control-group" style="background: #f8f9fa; border-color: #28a745;">
            <div class="group-title" style="color:#28a745">Export / Download</div>
            <div style="margin-bottom:8px;">
                <input type="text" id="fileName" placeholder="File Name (e.g. my-notes)" style="width:100%">
            </div>
            <div class="btn-row">
                <button class="btn-green" onclick="downloadTxt()">⬇ Download .TXT</button>
                <button class="btn-dark" onclick="downloadZip()">🤐 Download .ZIP</button>
            </div>
        </div>

    </div>
</center>
`;

app.innerHTML = toolHTML;

// --- Functions ---

// 1. File Import Function (NEW)
window.importFile = function(input) {
    var file = input.files[0];
    if (!file) return;

    var reader = new FileReader();
    reader.onload = function(e) {
        // Load text into textarea
        document.getElementById('mainText').value = e.target.result;
        
        // Auto set filename for export based on imported file
        var nameWithoutExt = file.name.split('.').slice(0, -1).join('.');
        if(nameWithoutExt) {
            document.getElementById('fileName').value = nameWithoutExt + "_edited";
        }
        
        updateStats();
    };
    reader.readAsText(file);
    
    // Reset input so same file can be selected again if needed
    input.value = '';
};

// 2. Stats Updater
window.updateStats = function() {
    var text = document.getElementById('mainText').value;
    document.getElementById('charCount').innerText = "Chars: " + text.length;
    document.getElementById('wordCount').innerText = "Words: " + (text.trim() === '' ? 0 : text.trim().split(/\s+/).length);
};

// 3. Clear & Copy
window.clearText = function() {
    document.getElementById('mainText').value = '';
    updateStats();
};
window.copyText = function() {
    var text = document.getElementById('mainText');
    text.select();
    document.execCommand("copy");
    alert("Copied to clipboard!");
};

// 4. Transformations
window.transform = function(type) {
    var el = document.getElementById('mainText');
    var val = el.value;
    
    if(!val) return;

    if(type === 'upper') val = val.toUpperCase();
    if(type === 'lower') val = val.toLowerCase();
    if(type === 'reverse') val = val.split('').reverse().join('');
    if(type === 'clean') val = val.replace(/\s+/g, ' ').trim();
    if(type === 'title') {
        val = val.toLowerCase().split(' ').map(function(word) {
            return word.replace(word[0], word[0].toUpperCase());
        }).join(' ');
    }
    
    el.value = val;
    updateStats();
};

// 5. Find & Replace
window.replaceText = function() {
    var find = document.getElementById('findTxt').value;
    var rep = document.getElementById('repTxt').value;
    var el = document.getElementById('mainText');
    
    if(!find) { alert("Enter text to find!"); return; }
    
    var regex = new RegExp(find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g');
    el.value = el.value.replace(regex, rep);
    updateStats();
};

// 6. Repeater
window.repeatText = function() {
    var count = parseInt(document.getElementById('repCount').value);
    var newLine = document.getElementById('newLineCheck').checked;
    var el = document.getElementById('mainText');
    var text = el.value;

    if(!text || isNaN(count) || count <= 0) { alert("Enter text and valid count!"); return; }
    
    if(count > 10000) {
        if(!confirm("Repeating huge amount allows browser to freeze. Continue?")) return;
    }

    var separator = newLine ? "\n" : " ";
    var result = new Array(count + 1).join(text + separator);
    
    el.value = result;
    updateStats();
};

// 7. Download as TXT
window.downloadTxt = function() {
    var text = document.getElementById('mainText').value;
    if(!text) { alert("No text to download!"); return; }
    
    var name = document.getElementById('fileName').value.trim() || "myfile";
    var blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name + ".txt";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};

// 8. Download as ZIP
window.downloadZip = function() {
    var text = document.getElementById('mainText').value;
    if(!text) { alert("No text to zip!"); return; }
    
    var name = document.getElementById('fileName').value.trim() || "myfile";
    
    if(typeof JSZip === 'undefined') {
        alert("JSZip library not found! Cannot create zip.");
        return;
    }

    var zip = new JSZip();
    zip.file(name + ".txt", text);
    
    zip.generateAsync({type:"blob"}).then(function(content) {
        var a = document.createElement("a");
        a.href = URL.createObjectURL(content);
        a.download = name + ".zip";
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
    });
};