/**
 * Universal Video to Audio Converter Core Engine
 * Handled completely client-side using Web Audio API and LAME JS.
 */

document.addEventListener('DOMContentLoaded', () => {
    // DOM Element References
    const dropZone = document.getElementById('dropZone');
    const fileInput = document.getElementById('fileInput');
    const fileInfo = document.getElementById('fileInfo');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    const fileSizeDisplay = document.getElementById('fileSizeDisplay');
    const removeFileBtn = document.getElementById('removeFileBtn');
    const convertBtn = document.getElementById('convertBtn');
    const formatSelect = document.getElementById('formatSelect');
    const bitrateSelect = document.getElementById('bitrateSelect');
    const bitrateContainer = document.getElementById('bitrateContainer');

    const uploadState = document.getElementById('uploadState');
    const processingState = document.getElementById('processingState');
    const resultState = document.getElementById('resultState');
    const progressStatus = document.getElementById('progressStatus');
    const progressBar = document.getElementById('progressBar');
    const progressText = document.getElementById('progressText');
    const errorAlert = document.getElementById('errorAlert');
    const audioPreview = document.getElementById('audioPreview');
    const downloadBtn = document.getElementById('downloadBtn');
    const resFileName = document.getElementById('resFileName');
    const resetBtn = document.getElementById('resetBtn');

    let selectedFile = null;

    // Toggle Bitrate selector visibility based on format selection
    formatSelect.addEventListener('change', () => {
        if (formatSelect.value === 'wav') {
            bitrateContainer.classList.add('opacity-50', 'pointer-events-none');
        } else {
            bitrateContainer.classList.remove('opacity-50', 'pointer-events-none');
        }
    });

    // Drag and Drop Event Handlers
    dropZone.addEventListener('click', () => fileInput.click());

    ['dragenter', 'dragover'].forEach((eventName) => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.add('border-indigo-500', 'bg-slate-800/50');
        });
    });

    ['dragleave', 'drop'].forEach((eventName) => {
        dropZone.addEventListener(eventName, (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-indigo-500', 'bg-slate-800/50');
        });
    });

    dropZone.addEventListener('drop', (e) => {
        if (e.dataTransfer.files.length) {
            handleFile(e.dataTransfer.files[0]);
        }
    });

    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length) {
            handleFile(e.target.files[0]);
        }
    });

    // Handle Selected File
    function handleFile(file) {
        hideError();
        selectedFile = file;
        fileNameDisplay.textContent = file.name;
        fileSizeDisplay.textContent = (file.size / (1024 * 1024)).toFixed(2) + ' MB';
        fileInfo.classList.remove('hidden');
        fileInfo.classList.add('flex');
        dropZone.classList.add('hidden');
        convertBtn.disabled = false;
    }

    removeFileBtn.addEventListener('click', resetUpload);

    function resetUpload() {
        selectedFile = null;
        fileInput.value = '';
        fileInfo.classList.add('hidden');
        fileInfo.classList.remove('flex');
        dropZone.classList.remove('hidden');
        convertBtn.disabled = true;
        hideError();
    }

    // Main Conversion Handler
    convertBtn.addEventListener('click', async () => {
        if (!selectedFile) return;

        uploadState.classList.add('hidden');
        processingState.classList.remove('hidden');
        hideError();
        updateProgress(10, 'Decoding video audio track...');

        try {
            const arrayBuffer = await selectedFile.arrayBuffer();
            const audioCtx = new (window.AudioContext || window.webkitAudioContext)();

            updateProgress(30, 'Demuxing audio streams...');
            const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);

            const format = formatSelect.value;
            const baseName = selectedFile.name.substring(0, selectedFile.name.lastIndexOf('.')) || selectedFile.name;
            let audioBlob, outFileName;

            if (format === 'mp3') {
                const bitrate = parseInt(bitrateSelect.value, 10);
                audioBlob = await encodeMp3(audioBuffer, bitrate);
                outFileName = `${baseName}.mp3`;
            } else {
                audioBlob = encodeWav(audioBuffer);
                outFileName = `${baseName}.wav`;
            }

            const audioUrl = URL.createObjectURL(audioBlob);

            // Display Results
            processingState.classList.add('hidden');
            resultState.classList.remove('hidden');

            audioPreview.src = audioUrl;
            downloadBtn.href = audioUrl;
            downloadBtn.download = outFileName;
            resFileName.textContent = `${outFileName} (${(audioBlob.size / (1024 * 1024)).toFixed(2)} MB)`;

        } catch (err) {
            console.error(err);
            processingState.classList.add('hidden');
            uploadState.classList.remove('hidden');
            showError('Failed to process video audio. Please verify that this video file contains an active audio track.');
        }
    });

    function updateProgress(percent, status) {
        progressBar.style.width = percent + '%';
        progressText.textContent = percent + '%';
        if (status) {
            progressStatus.textContent = status;
        }
    }

    // MP3 Encoder Implementation (Using LAME JS)
    function encodeMp3(audioBuffer, bitrate) {
        return new Promise((resolve) => {
            const channels = audioBuffer.numberOfChannels;
            const sampleRate = audioBuffer.sampleRate;
            const mp3encoder = new lamejs.Mp3Encoder(channels, sampleRate, bitrate);
            const mp3Data = [];

            const sampleBlockSize = 1152;
            const left = audioBuffer.getChannelData(0);
            const right = channels > 1 ? audioBuffer.getChannelData(1) : left;

            const leftInt16 = convertFloatToInt16(left);
            const rightInt16 = channels > 1 ? convertFloatToInt16(right) : leftInt16;

            const totalSamples = leftInt16.length;
            let processed = 0;

            function processChunk() {
                const end = Math.min(processed + sampleBlockSize * 10, totalSamples);
                for (let i = processed; i < end; i += sampleBlockSize) {
                    const leftChunk = leftInt16.subarray(i, i + sampleBlockSize);
                    const rightChunk = channels > 1 ? rightInt16.subarray(i, i + sampleBlockSize) : leftChunk;

                    let mp3buf;
                    if (channels === 1) {
                        mp3buf = mp3encoder.encodeBuffer(leftChunk);
                    } else {
                        mp3buf = mp3encoder.encodeBuffer(leftChunk, rightChunk);
                    }
                    if (mp3buf.length > 0) mp3Data.push(mp3buf);
                }

                processed = end;
                const percent = Math.min(95, 30 + Math.round((processed / totalSamples) * 65));
                updateProgress(percent, `Encoding to MP3 (${bitrate} kbps)...`);

                if (processed < totalSamples) {
                    setTimeout(processChunk, 0);
                } else {
                    const endBuf = mp3encoder.flush();
                    if (endBuf.length > 0) mp3Data.push(endBuf);
                    updateProgress(100, 'Done!');
                    resolve(new Blob(mp3Data, { type: 'audio/mp3' }));
                }
            }

            processChunk();
        });
    }

    function convertFloatToInt16(float32Array) {
        const int16Array = new Int16Array(float32Array.length);
        for (let i = 0; i < float32Array.length; i++) {
            let s = Math.max(-1, Math.min(1, float32Array[i]));
            int16Array[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
        }
        return int16Array;
    }

    // Lossless WAV Encoder Implementation
    function encodeWav(audioBuffer) {
        updateProgress(90, 'Packing Lossless WAV audio...');
        const numChannels = audioBuffer.numberOfChannels;
        const sampleRate = audioBuffer.sampleRate;
        const format = 1; // PCM
        const bitDepth = 16;

        const samples = audioBuffer.length;
        const blockAlign = numChannels * (bitDepth / 8);
        const byteRate = sampleRate * blockAlign;
        const dataSize = samples * blockAlign;
        const buffer = new ArrayBuffer(44 + dataSize);
        const view = new DataView(buffer);

        function writeString(offset, string) {
            for (let i = 0; i < string.length; i++) {
                view.setUint8(offset + i, string.charCodeAt(i));
            }
        }

        // RIFF Header
        writeString(0, 'RIFF');
        view.setUint32(4, 36 + dataSize, true);
        writeString(8, 'WAVE');

        // "fmt " Sub-chunk
        writeString(12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, format, true);
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, byteRate, true);
        view.setUint16(32, blockAlign, true);
        view.setUint16(34, bitDepth, true);

        // "data" Sub-chunk
        writeString(36, 'data');
        view.setUint32(40, dataSize, true);

        // Interleave PCM Samples
        const channelsData = [];
        for (let c = 0; c < numChannels; c++) {
            channelsData.push(audioBuffer.getChannelData(c));
        }

        let offset = 44;
        for (let i = 0; i < samples; i++) {
            for (let c = 0; c < numChannels; c++) {
                let sample = Math.max(-1, Math.min(1, channelsData[c][i]));
                sample = sample < 0 ? sample * 0x8000 : sample * 0x7FFF;
                view.setInt16(offset, sample, true);
                offset += 2;
            }
        }

        updateProgress(100, 'Done!');
        return new Blob([buffer], { type: 'audio/wav' });
    }

    // Reset Tool State
    resetBtn.addEventListener('click', () => {
        resultState.classList.add('hidden');
        uploadState.classList.remove('hidden');
        audioPreview.pause();
        audioPreview.src = '';
        resetUpload();
    });

    function showError(msg) {
        errorAlert.textContent = msg;
        errorAlert.classList.remove('hidden');
    }

    function hideError() {
        errorAlert.classList.add('hidden');
        errorAlert.textContent = '';
    }
});