var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Design ---
var toolHTML = `
<style>
    .dc-box { background: #fff; padding: 15px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    textarea { width: 100%; height: 120px; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace; font-size: 12px; resize: vertical; box-sizing: border-box; }
    .controls { display: flex; gap: 10px; margin: 10px 0; flex-wrap: wrap; }
    select, button { padding: 10px; border: 1px solid #ddd; border-radius: 4px; flex: 1; cursor: pointer; }
    .btn-primary { background: #007bff; color: white; border: none; font-weight: bold; }
    .btn-success { background: #28a745; color: white; border: none; font-weight: bold; }
    .checkbox-area { text-align: left; padding: 10px; border: 1px solid #eee; margin: 10px 0; display: none; background: #f9f9f9; max-height: 150px; overflow-y: auto; }
    .checkbox-item { display: inline-block; margin-right: 15px; margin-bottom: 5px; }
    label { cursor: pointer; }
    h3 { margin: 5px 0; font-size: 16px; color: #555; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>Universal Data Converter</h1>
    
    <div class="dc-box">
        <h3>1. Input Data</h3>
        <textarea id="inputData" placeholder="Paste your JSON, CSV, or HTML Table code here..."></textarea>
        
        <div class="controls">
            <select id="inputType">
                <option value="json">Input: JSON</option>
                <option value="csv">Input: CSV</option>
                <option value="html">Input: HTML Table</option>
            </select>
            <button class="btn-primary" onclick="loadColumns()">Load Columns</button>
        </div>

        <!-- কলাম সিলেকশন এরিয়া -->
        <div id="columnSelector" class="checkbox-area">
            <small style="display:block;margin-bottom:5px;color:red;">* Select columns to keep:</small>
            <div id="checkboxContainer"></div>
        </div>

        <h3>2. Output Options</h3>
        <div class="controls">
            <select id="outputType">
                <option value="json">To: JSON</option>
                <option value="csv">To: CSV</option>
                <option value="html">To: HTML Table</option>
            </select>
            <button class="btn-success" onclick="convertData()">Convert Data</button>
        </div>

        <h3>3. Result</h3>
        <textarea id="outputData" readonly placeholder="Result will appear here..."></textarea>
    </div>
</center>
`;

app.innerHTML = toolHTML;

// --- Global Variable to hold parsed data ---
window.parsedData = []; 

// --- Helper Functions ---

// CSV Parser
function parseCSV(text) {
    var lines = text.trim().split('\n');
    var headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    var result = [];
    for(var i=1; i<lines.length; i++) {
        var obj = {};
        var currentline = lines[i].split(','); // Simple split (complex regex omitted for speed)
        for(var j=0; j<headers.length; j++) {
            var val = currentline[j] ? currentline[j].trim().replace(/^"|"$/g, '') : '';
            obj[headers[j]] = val;
        }
        result.push(obj);
    }
    return result;
}

// HTML Table Parser
function parseHTMLTable(htmlString) {
    var parser = new DOMParser();
    var doc = parser.parseFromString(htmlString, 'text/html');
    var table = doc.querySelector('table');
    if(!table) return [];
    
    var data = [];
    var headers = [];
    var rows = table.querySelectorAll('tr');
    
    // Get Headers
    var headerCells = rows[0].querySelectorAll('th, td');
    for(var i=0; i<headerCells.length; i++) {
        headers.push(headerCells[i].innerText.trim());
    }

    // Get Data
    for(var i=1; i<rows.length; i++) {
        var cells = rows[i].querySelectorAll('td');
        var obj = {};
        for(var j=0; j<cells.length; j++) {
            if(headers[j]) {
                obj[headers[j]] = cells[j].innerText.trim();
            }
        }
        data.push(obj);
    }
    return data;
}

// --- Main Logic ---

window.loadColumns = function() {
    var input = document.getElementById('inputData').value.trim();
    var type = document.getElementById('inputType').value;
    var container = document.getElementById('checkboxContainer');
    var selectorArea = document.getElementById('columnSelector');

    if(!input) { alert("Please enter data first!"); return; }

    try {
        if(type === 'json') {
            window.parsedData = JSON.parse(input);
            if(!Array.isArray(window.parsedData)) window.parsedData = [window.parsedData];
        } else if(type === 'csv') {
            window.parsedData = parseCSV(input);
        } else if(type === 'html') {
            window.parsedData = parseHTMLTable(input);
        }

        if(window.parsedData.length === 0) {
            alert("No valid data found!");
            return;
        }

        // Generate Checkboxes based on keys of first object
        var keys = Object.keys(window.parsedData[0]);
        var html = '';
        keys.forEach(key => {
            html += `<div class="checkbox-item">
                <input type="checkbox" id="col_${key}" value="${key}" checked>
                <label for="col_${key}">${key}</label>
            </div>`;
        });

        container.innerHTML = html;
        selectorArea.style.display = 'block';

    } catch(e) {
        alert("Error parsing data. Check format!");
        console.error(e);
    }
};

window.convertData = function() {
    if(!window.parsedData || window.parsedData.length === 0) {
        alert("Please load columns first!");
        return;
    }

    // 1. Get Selected Columns
    var checkboxes = document.querySelectorAll('#checkboxContainer input[type="checkbox"]:checked');
    var selectedKeys = Array.from(checkboxes).map(cb => cb.value);

    if(selectedKeys.length === 0) {
        alert("Select at least one column!");
        return;
    }

    // 2. Filter Data
    var filteredData = window.parsedData.map(item => {
        var newItem = {};
        selectedKeys.forEach(key => {
            newItem[key] = item[key] !== undefined ? item[key] : "";
        });
        return newItem;
    });

    // 3. Convert to Output Format
    var outType = document.getElementById('outputType').value;
    var outputBox = document.getElementById('outputData');
    var resultStr = "";

    if(outType === 'json') {
        resultStr = JSON.stringify(filteredData, null, 2);
    } 
    else if(outType === 'csv') {
        var header = selectedKeys.join(',') + "\n";
        var rows = filteredData.map(obj => {
            return selectedKeys.map(key => JSON.stringify(obj[key])).join(',');
        }).join('\n');
        resultStr = header + rows;
    } 
    else if(outType === 'html') {
        var th = selectedKeys.map(k => `<th>${k}</th>`).join('');
        var trs = filteredData.map(obj => {
            var tds = selectedKeys.map(k => `<td>${obj[k]}</td>`).join('');
            return `<tr>${tds}</tr>`;
        }).join('');
        resultStr = `<table border="1">\n<thead><tr>${th}</tr></thead>\n<tbody>\n${trs}\n</tbody>\n</table>`;
    }

    outputBox.value = resultStr;
};