var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Design ---
var toolHTML = `
<style>
    .cv-box { background: #fff; padding: 15px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    
    textarea { 
        width: 100%; height: 300px; padding: 10px; border: 1px solid #ccc; 
        border-radius: 4px; font-family: 'Courier New', monospace; font-size: 13px; 
        resize: vertical; box-sizing: border-box; background: #2d2d2d; color: #f8f8f2; white-space: pre; overflow: auto;
    }
    
    .status-bar {
        padding: 10px; border-radius: 4px; margin-bottom: 10px; font-weight: bold; font-size: 14px;
        display: none; text-align: left; border: 1px solid transparent;
    }
    .status-success { background: #d4edda; color: #155724; border-color: #c3e6cb; }
    .status-error { background: #f8d7da; color: #721c24; border-color: #f5c6cb; }

    .controls { display: flex; gap: 8px; margin-bottom: 10px; flex-wrap: wrap; }
    select, button { padding: 8px; border: 1px solid #ddd; border-radius: 4px; cursor: pointer; flex: 1; min-width: 100px; }
    
    .btn-blue { background: #007bff; color: white; border: none; }
    .btn-green { background: #28a745; color: white; border: none; }
    .btn-dark { background: #343a40; color: white; border: none; }
    .btn-warn { background: #ffc107; color: #333; border: none; }
    .btn-red { background: #dc3545; color: white; border: none; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>Code Validator & Fixer</h1>
    
    <div class="cv-box">
        
        <!-- Controls -->
        <div class="controls">
            <input type="file" id="fileImport" style="display:none" onchange="importFile(this)">
            <button class="btn-warn" onclick="document.getElementById('fileImport').click()">📂 Open File</button>
            <button class="btn-red" onclick="document.getElementById('editor').value=''; showStatus('Cleared', 'success');">🗑 Clear</button>
            
            <select id="codeType">
                <option value="json">JSON</option>
                <option value="html">HTML</option>
                <option value="css">CSS</option>
                <option value="js">JavaScript</option>
                <option value="csv">CSV</option>
            </select>
        </div>

        <!-- Status Message -->
        <div id="statusMsg" class="status-bar"></div>

        <!-- Editor -->
        <textarea id="editor" placeholder="Paste your code here..." spellcheck="false"></textarea>

        <!-- Actions -->
        <div class="controls" style="margin-top:10px;">
            <button class="btn-blue" onclick="validateCode()">🔍 Validate</button>
            <button class="btn-green" onclick="formatCode()">✨ Fix / Format</button>
        </div>
        
        <div class="controls">
            <button class="btn-dark" onclick="copyCode()">📋 Copy</button>
            <button class="btn-dark" onclick="downloadCode()">⬇ Download</button>
        </div>

    </div>
</center>
`;

app.innerHTML = toolHTML;

// --- Helper: Show Status ---
function showStatus(msg, type) {
    var el = document.getElementById('statusMsg');
    el.style.display = 'block';
    el.className = 'status-bar ' + (type === 'error' ? 'status-error' : 'status-success');
    el.innerText = msg;
    // Auto hide after 5 seconds
    setTimeout(() => { el.style.display = 'none'; }, 5000);
}

// --- 1. Import File ---
window.importFile = function(input) {
    var file = input.files[0];
    if (!file) return;

    var reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('editor').value = e.target.result;
        
        var ext = file.name.split('.').pop().toLowerCase();
        var select = document.getElementById('codeType');
        if(['json','html','css','js','csv'].includes(ext)) {
            select.value = ext;
        } else if (ext === 'htm') select.value = 'html';
        else if (ext === 'txt') select.value = 'json'; // default fallback
        
        showStatus("File Loaded: " + file.name, "success");
    };
    reader.readAsText(file);
    input.value = '';
};

// --- 2. Validate Logic ---
window.validateCode = function() {
    var code = document.getElementById('editor').value;
    var type = document.getElementById('codeType').value;
    
    if(!code.trim()) { showStatus("Editor is empty!", "error"); return; }

    try {
        if (type === 'json') {
            JSON.parse(code); 
            showStatus("✅ Valid JSON!", "success");
        } 
        else if (type === 'html') {
            // Check for unclosed tags (Basic check)
            var parser = new DOMParser();
            var doc = parser.parseFromString(code, "text/html");
            var errorNode = doc.querySelector("parsererror");
            if (errorNode) throw new Error("Parsing Error");
            
            // Simple logic: count < and >
            var open = (code.match(/</g) || []).length;
            var close = (code.match(/>/g) || []).length;
            if(open !== close) throw new Error("Mismatch of '<' and '>' characters.");
            
            showStatus("✅ Valid HTML Structure!", "success");
        }
        else if (type === 'csv') {
            var lines = code.trim().split('\n');
            if (lines.length === 0) throw new Error("Empty CSV");
            var colCount = lines[0].split(',').length;
            for(var i=1; i<lines.length; i++) {
                if(lines[i].trim() && lines[i].split(',').length !== colCount) {
                    throw new Error(`Row ${i+1} has different column count!`);
                }
            }
            showStatus(`✅ Valid CSV! (${lines.length} rows)`, "success");
        }
        else if (type === 'js') {
            // Function constructor throws error on syntax failure
            new Function(code); 
            showStatus("✅ Valid JavaScript Syntax!", "success");
        }
        else if (type === 'css') {
            if(code.includes('{') && code.includes('}')) {
                showStatus("✅ CSS looks okay.", "success");
            } else {
                throw new Error("Invalid CSS structure.");
            }
        }
    } catch (e) {
        showStatus("❌ Error: " + e.message, "error");
    }
};

// --- 3. Format / Fix Logic ---
window.formatCode = function() {
    var el = document.getElementById('editor');
    var code = el.value;
    var type = document.getElementById('codeType').value;

    if(!code.trim()) return;

    try {
        if (type === 'json') {
            var obj = JSON.parse(code);
            el.value = JSON.stringify(obj, null, 4); 
            showStatus("✨ JSON Beautified!", "success");
        }
        else if (type === 'css') {
            var formatted = code
                .replace(/\s*\{\s*/g, ' {\n    ')
                .replace(/;\s*/g, ';\n    ')
                .replace(/\s*\}\s*/g, '\n}\n')
                .replace(/\n\s*\n/g, '\n');
            el.value = formatted.trim();
            showStatus("✨ CSS Formatted!", "success");
        }
        else if (type === 'html') {
            el.value = formatHTML(code);
            showStatus("✨ HTML Beautified!", "success");
        }
        else if (type === 'js') {
            // FIXED Syntax Error here
            var formatted = code
                .replace(/{\s*/g, ' {\n    ')  // Fixed slash
                .replace(/;\s*/g, ';\n')
                .replace(/}\s*/g, '\n}\n')
                .replace(/\n\s*\n/g, '\n'); 
            el.value = formatted;
            showStatus("✨ JS Formatted (Basic)", "success");
        }
        else if (type === 'csv') {
            el.value = code.split('\n').map(r => r.split(',').map(c => c.trim()).join(',')).join('\n');
            showStatus("✨ CSV Cleaned!", "success");
        }
    } catch (e) {
        showStatus("Cannot format: Fix syntax errors first.", "error");
        console.log(e);
    }
};

// --- Helper: Better HTML Formatter ---
function formatHTML(html) {
    var tab = '    ';
    var result = '';
    var indent = '';
    
    // Remove extra whitespace between tags first
    html = html.replace(/>\s+</g, '><').trim();
    
    // Split by tags
    var parts = html.split(/(<[^>]+>)/g);
    
    parts.forEach(function(element) {
        if (!element.trim()) return;
        
        // Closing tag
        if (element.match(/^<\//)) {
            indent = indent.substring(tab.length);
            result += indent + element + '\n';
        }
        // Self-closing or DOCTYPE or Comment
        else if (element.match(/^<!/) || element.match(/\/>$/)) {
            result += indent + element + '\n';
        }
        // Opening tag
        else if (element.match(/^</)) {
            result += indent + element + '\n';
            // Check for void tags that don't need closing (like <br>, <img>, <input>)
            var tagName = element.match(/^<([a-z0-9]+)/i);
            var voidTags = ['area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'];
            
            if (tagName && !voidTags.includes(tagName[1].toLowerCase())) {
                indent += tab;
            }
        }
        // Text Content
        else {
            result += indent + element.trim() + '\n';
        }
    });
    
    return result.trim();
}

// --- 4. Export Functions ---
window.copyCode = function() {
    var text = document.getElementById('editor');
    text.select();
    document.execCommand("copy");
    showStatus("Copied to clipboard!", "success");
};

window.downloadCode = function() {
    var text = document.getElementById('editor').value;
    var type = document.getElementById('codeType').value;
    var extMap = { 'json': '.json', 'html': '.html', 'css': '.css', 'js': '.js', 'csv': '.csv' };
    
    var blob = new Blob([text], { type: "text/plain" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "fixed_code" + (extMap[type] || ".txt");
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};