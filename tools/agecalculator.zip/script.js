// আগের কন্টেন্ট ক্লিয়ার করা হচ্ছে
var app = document.getElementById('container');
app.innerHTML = ''; 

// টুলের ডিজাইন (HTML & CSS)
var toolHTML = `
<style>
    .age-box {
        background: #fff;
        padding: 20px;
        margin: 10px;
        border-radius: 10px;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        text-align: center;
    }
    .age-input {
        width: 80%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ddd;
        border-radius: 5px;
    }
    .age-btn {
        background: #007bff;
        color: white;
        border: none;
        padding: 10px 20px;
        border-radius: 5px;
        cursor: pointer;
        font-size: 16px;
    }
    .result-box {
        margin-top: 20px;
        font-size: 18px;
        font-weight: bold;
        color: #333;
    }
    .back-btn {
        margin-top: 20px;
        background: #ff4444;
        color: white;
        border: none;
        padding: 8px 15px;
        border-radius: 5px;
        cursor: pointer;
    }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>Age Calculator</h1>
    <div class="age-box">
        <p>Enter Your Date of Birth:</p>
        <input type="date" id="dob" class="age-input">
        <br>
        <button onclick="calculateAge()" class="age-btn">Calculate Age</button>
        
        <div id="result" class="result-box"></div>
    </div>
</center>
`;

// HTML কন্টেইনারে পুশ করা
app.innerHTML = toolHTML;

// ক্যালকুলেশন লজিক ফাংশন
window.calculateAge = function() {
    var dobInput = document.getElementById('dob').value;
    var resultDiv = document.getElementById('result');

    if (!dobInput) {
        resultDiv.innerHTML = "<span style='color:red'>Please select a date!</span>";
        return;
    }

    var dob = new Date(dobInput);
    var today = new Date();

    var years = today.getFullYear() - dob.getFullYear();
    var months = today.getMonth() - dob.getMonth();
    var days = today.getDate() - dob.getDate();

    // মাস বা দিন নেগেটিভ হলে অ্যাডজাস্টমেন্ট
    if (days < 0) {
        months--;
        // আগের মাসের দিন সংখ্যা বের করা
        var lastMonthDate = new Date(today.getFullYear(), today.getMonth(), 0).getDate();
        days += lastMonthDate;
    }
    if (months < 0) {
        years--;
        months += 12;
    }

    resultDiv.innerHTML = `Your Age is:<br> <span style="color:blue; font-size:22px">${years} Years, ${months} Months, ${days} Days</span>`;
};