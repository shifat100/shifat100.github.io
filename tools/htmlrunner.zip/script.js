var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Layout & CSS ---
var toolHTML = `
<style>
    .ide-container { display: flex; flex-direction: column; height: calc(100vh - 100px); background: #1e1e1e; color: #ddd; }
    
    /* Toolbar */
    .toolbar { display: flex; gap: 5px; padding: 10px; background: #252526; border-bottom: 1px solid #333; overflow-x: auto; }
    .btn-tool { background: #333; color: white; border: 1px solid #444; padding: 6px 12px; border-radius: 4px; cursor: pointer; white-space: nowrap; font-size: 12px; }
    .btn-run { background: #28a745; border-color: #28a745; font-weight: bold; }
    .btn-clear { background: #dc3545; border-color: #dc3545; }
    
    /* Split View */
    .split-view { display: flex; flex: 1; flex-direction: column; overflow: hidden; }
    
    /* Editor */
    #editor { 
        flex: 1; background: #1e1e1e; color: #d4d4d4; border: none; padding: 15px; 
        font-family: 'Courier New', monospace; font-size: 14px; resize: none; outline: none; 
        white-space: pre; border-bottom: 2px solid #333;
    }

    /* Preview Area */
    .preview-wrapper { flex: 1; background: #fff; position: relative; display: flex; justify-content: center; background: #333; }
    iframe { width: 100%; height: 100%; border: none; background: #fff; transition: width 0.3s; }
    
    /* Console / Inspector */
    .console-box { 
        height: 150px; background: #111; border-top: 1px solid #444; 
        font-family: monospace; font-size: 12px; overflow-y: auto; display: flex; flex-direction: column;
    }
    .console-header { background: #252526; padding: 5px 10px; font-weight: bold; font-size: 11px; color: #aaa; display: flex; justify-content: space-between; }
    .log-entry { padding: 4px 10px; border-bottom: 1px solid #222; word-wrap: break-word; }
    .log-info { color: #d4d4d4; }
    .log-warn { color: #ffc107; background: #2a2500; }
    .log-error { color: #ff6b6b; background: #290000; border-left: 3px solid #ff6b6b; }

    /* Tabs */
    .tab-btn { background: transparent; border: none; color: #888; cursor: pointer; padding: 5px; }
    .tab-active { color: #fff; border-bottom: 2px solid #007bff; }

    @media (min-width: 768px) {
        .split-view { flex-direction: row; }
        #editor { width: 40%; border-right: 1px solid #333; border-bottom: none; }
    }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<div class="ide-container">
    <!-- Top Toolbar -->
    <div class="toolbar">
        <button class="btn-tool btn-run" onclick="runCode()">▶ Run Code</button>
        <button class="btn-tool" onclick="document.getElementById('fileUpload').click()">📂 Open</button>
        <input type="file" id="fileUpload" style="display:none" onchange="openFile(this)">
        <button class="btn-tool" onclick="downloadCode()">⬇ Save</button>
        <span style="flex:1"></span>
        <button class="btn-tool" onclick="resizeFrame('100%')">Desktop</button>
        <button class="btn-tool" onclick="resizeFrame('375px')">Mobile</button>
    </div>

    <!-- Main Workspace -->
    <div class="split-view">
        <textarea id="editor" placeholder="<!-- Write HTML, CSS, JS here -->
<html>
<head>
  <style>
    body { font-family: sans-serif; padding: 20px; }
    h1 { color: #007bff; }
  </style>
</head>
<body>
  <h1>Hello World!</h1>
  <button onclick='testConsole()'>Click Me</button>

  <script>
    console.log('System Ready...');
    function testConsole() {
       console.log('Button Clicked!');
       console.warn('This is a warning');
       // Intentional Error to test checker
       // nonExistentFunction(); 
    }
  </script>
</body>
</html>" spellcheck="false"></textarea>
        
        <div class="preview-wrapper">
            <iframe id="previewFrame"></iframe>
        </div>
    </div>

    <!-- Bottom Console -->
    <div class="console-box">
        <div class="console-header">
            <span>CONSOLE & ERRORS</span>
            <button class="tab-btn" onclick="clearConsole()">🚫 Clear</button>
        </div>
        <div id="consoleLogs"></div>
    </div>
</div>
`;

app.innerHTML = toolHTML;

// --- Core Logic ---

// 1. Run Code & Inject Console Interceptor
window.runCode = function() {
    var code = document.getElementById('editor').value;
    var iframe = document.getElementById('previewFrame');
    var logs = document.getElementById('consoleLogs');
    
    // Clear console before run
    logs.innerHTML = ''; 
    addLog('System', 'Starting execution...', 'info');

    var doc = iframe.contentWindow.document;
    doc.open();
    
    // Inject Custom Console Script inside the iframe
    // This script overwrites the iframe's console functions to send data back to our UI
    var consoleScript = `
    <script>
        (function() {
            var oldLog = console.log;
            var oldWarn = console.warn;
            var oldError = console.error;

            function sendToParent(type, args) {
                try {
                    // Convert args to string array
                    var msg = args.map(arg => {
                        if (typeof arg === 'object') return JSON.stringify(arg);
                        return String(arg);
                    }).join(' ');
                    
                    // Call parent function exposed via window.parent
                    window.parent.postLog(type, msg);
                } catch(e) {}
            }

            console.log = function(...args) { oldLog.apply(console, args); sendToParent('info', args); };
            console.warn = function(...args) { oldWarn.apply(console, args); sendToParent('warn', args); };
            console.error = function(...args) { oldError.apply(console, args); sendToParent('error', args); };

            // Catch Syntax/Runtime Errors
            window.onerror = function(msg, url, line) {
                sendToParent('error', ['[Line ' + line + '] ' + msg]);
                return false; 
            };
        })();
    <\/script>
    `;

    // Combine script and user code
    // IMPORTANT: Adding the console script BEFORE user code so it catches everything
    doc.write(consoleScript + code);
    doc.close();
};

// 2. Receive Logs from Iframe (Exposed Globally)
window.postLog = function(type, msg) {
    addLog(type.toUpperCase(), msg, type);
};

// 3. Helper to display logs in UI
function addLog(label, message, type) {
    var div = document.createElement('div');
    div.className = 'log-entry log-' + type;
    
    var time = new Date().toLocaleTimeString().split(' ')[0];
    div.innerHTML = `<span style="opacity:0.6">[${time}]</span> <b>${label}:</b> ${message}`;
    
    var container = document.getElementById('consoleLogs');
    container.appendChild(div);
    container.scrollTop = container.scrollHeight; // Auto scroll to bottom
}

// 4. Viewport Resizer
window.resizeFrame = function(width) {
    document.getElementById('previewFrame').style.width = width;
};

// 5. Clear Console
window.clearConsole = function() {
    document.getElementById('consoleLogs').innerHTML = '';
};

// 6. Open File
window.openFile = function(input) {
    var file = input.files[0];
    if(!file) return;
    var reader = new FileReader();
    reader.onload = function(e) {
        document.getElementById('editor').value = e.target.result;
        runCode(); // Auto run on load
    };
    reader.readAsText(file);
    input.value = '';
};

// 7. Download Code
window.downloadCode = function() {
    var code = document.getElementById('editor').value;
    var blob = new Blob([code], {type: "text/html"});
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = "index.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
};

// Auto run initial demo code
setTimeout(window.runCode, 500);