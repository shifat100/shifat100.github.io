(function() {
    const container = document.getElementById('container');

    // CSS Styles
    const styles = `
        <style>
            @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css');
            @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap');

            .header {
                display: flex;
                align-items: center;
                padding: 15px;
                background-color: #f8f9fa;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
                margin-bottom: 20px;
                font-family: 'Roboto', sans-serif;
            }
            .back-btn {
                font-size: 1.2rem;
                cursor: pointer;
                margin-right: 15px;
                color: #333;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                transition: background 0.2s;
            }
            .back-btn:active {
                background-color: #e2e6ea;
            }
            .tool-title {
                font-size: 1.2rem;
                font-weight: 600;
                color: #2c3e50;
            }
            .compass-container {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 20px;
                font-family: 'Roboto', sans-serif;
                position: relative;
            }
            .compass-housing {
                width: 300px;
                height: 300px;
                border-radius: 50%;
                background: linear-gradient(135deg, #e0e0e0, #ffffff);
                box-shadow:  20px 20px 60px #bebebe, -20px -20px 60px #ffffff;
                display: flex;
                align-items: center;
                justify-content: center;
                position: relative;
                margin-bottom: 30px;
                border: 5px solid #333;
            }
            .compass-dial {
                width: 260px;
                height: 260px;
                background-image: url('https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Compass_rose_en_04p.svg/1024px-Compass_rose_en_04p.svg.png');
                background-size: contain;
                background-repeat: no-repeat;
                background-position: center;
                transition: transform 0.2s cubic-bezier(0.25, 0.46, 0.45, 0.94);
                position: relative;
            }
            /* The fixed red marker at the top for Sensor Mode */
            .fixed-marker {
                position: absolute;
                top: -10px;
                left: 50%;
                transform: translateX(-50%);
                width: 0; 
                height: 0; 
                border-left: 15px solid transparent;
                border-right: 15px solid transparent;
                border-top: 20px solid #ff3333;
                z-index: 10;
            }
            
            /* Sun Icon for Sun Mode */
            .sun-marker {
                position: absolute;
                top: -25px;
                left: 50%;
                transform: translateX(-50%);
                font-size: 2rem;
                color: #f39c12;
                display: none;
                z-index: 10;
                animation: spin-sun 10s linear infinite;
            }

            @keyframes spin-sun { 100% { transform: translateX(-50%) rotate(360deg); } }

            .degree-display {
                font-family: 'Orbitron', sans-serif;
                font-size: 2.5rem;
                font-weight: 700;
                color: #333;
                margin-bottom: 10px;
            }
            .direction-text {
                font-size: 1.2rem;
                color: #666;
                font-weight: 500;
            }
            .mode-badge {
                margin-top: 15px;
                padding: 5px 15px;
                border-radius: 20px;
                font-size: 0.9rem;
                font-weight: bold;
            }
            .mode-sensor { background: #d4edda; color: #155724; }
            .mode-sun { background: #fff3cd; color: #856404; }

            .btn-ios {
                margin-top: 20px;
                padding: 10px 20px;
                background-color: #007bff;
                color: white;
                border: none;
                border-radius: 5px;
                display: none;
            }
            .info-text {
                margin-top: 20px;
                text-align: center;
                color: #777;
                font-size: 0.9rem;
                padding: 0 20px;
            }
        </style>
    `;

    // HTML Structure
    const html = `
        <div class="header">
            <span class="back-btn" onclick="location.reload()">
                <i class="fa-solid fa-arrow-left"></i>
            </span>
            <span class="tool-title">Smart Compass</span>
        </div>

        <div class="compass-container">
            <div class="degree-display"><span id="degreeVal">0</span>° <span id="dirText">N</span></div>
            
            <div class="compass-housing">
                <div class="fixed-marker" id="mainMarker"></div>
                <div class="sun-marker" id="sunMarker"><i class="fa-solid fa-sun"></i></div>
                <div class="compass-dial" id="compassDial"></div>
            </div>

            <div id="modeBadge" class="mode-badge mode-sensor">Sensor Mode</div>
            
            <button class="btn-ios" id="iosPermBtn">Allow Compass Access</button>

            <div class="info-text" id="infoText">
                Hold device flat parallel to the ground.
            </div>
            
            <button onclick="window.forceSunMode()" style="margin-top:15px; background:none; border:none; color:#007bff; text-decoration:underline; cursor:pointer;">
                Force Sun Mode
            </button>
        </div>
    `;

    container.innerHTML = styles + html;

    // --- LOGIC ---

    const compassDial = document.getElementById('compassDial');
    const degreeVal = document.getElementById('degreeVal');
    const dirText = document.getElementById('dirText');
    const modeBadge = document.getElementById('modeBadge');
    const iosBtn = document.getElementById('iosPermBtn');
    const infoText = document.getElementById('infoText');
    const mainMarker = document.getElementById('mainMarker');
    const sunMarker = document.getElementById('sunMarker');

    let isSunMode = false;

    // Helper: Degrees to Cardinal Direction
    function getCardinal(angle) {
        const directions = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
        return directions[Math.round(angle / 45) % 8];
    }

    // 1. SENSOR MODE LOGIC
    function handleOrientation(event) {
        if(isSunMode) return;

        let heading = null;

        // Android / Non-iOS
        if (event.absolute && event.alpha !== null) {
            heading = event.alpha;
        } 
        // iOS Webkit
        else if (event.webkitCompassHeading) {
            heading = event.webkitCompassHeading;
        }

        if (heading !== null) {
            // Invert the rotation for the dial so North stays North
            // If heading is 90 (East), dial must rotate -90 so "E" is at top
            compassDial.style.transform = `rotate(-${heading}deg)`;
            
            degreeVal.innerText = Math.round(heading);
            dirText.innerText = getCardinal(heading);
        }
    }

    // 2. SUN MODE LOGIC (Fallback)
    function enableSunMode() {
        isSunMode = true;
        modeBadge.className = 'mode-badge mode-sun';
        modeBadge.innerText = 'Sun Mode (Fallback)';
        
        // UI Changes
        mainMarker.style.display = 'none';
        sunMarker.style.display = 'block';
        iosBtn.style.display = 'none';

        infoText.innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i> <b>How to use:</b><br>Point the TOP of your phone directly at the SUN.<br>The compass will align to show North based on time.`;

        updateSunCompass();
        // Update every minute
        setInterval(updateSunCompass, 60000);
    }

    function updateSunCompass() {
        if(!isSunMode) return;

        const now = new Date();
        const hour = now.getHours();
        const minutes = now.getMinutes();
        
        // Approximate Sun Position Logic (Northern Hemisphere assumption)
        // 6:00 = 90 deg (East)
        // 12:00 = 180 deg (South)
        // 18:00 = 270 deg (West)
        // Formula: 15 degrees per hour. Base 6am = 90.
        
        let decimalTime = hour + (minutes / 60);
        
        // If night time (6pm to 6am), this is inaccurate, but let's just allow it or show error
        if (decimalTime < 6 || decimalTime > 18) {
             infoText.innerHTML = "⚠️ Sun mode only works during daylight hours (6 AM - 6 PM).";
             // still calculate roughly
        }

        // Calculate Sun Azimuth roughly
        // (Time - 6) * 15 + 90
        let sunAzimuth = ((decimalTime - 6) * 15) + 90;
        
        // Wrap around
        sunAzimuth = sunAzimuth % 360;

        // If user points phone at Sun, phone's heading is 'sunAzimuth'.
        // We want to show North. 
        // We need to rotate the dial such that the North marker is in the correct place relative to the Sun (Top).
        // Rotate Dial = 360 - sunAzimuth
        
        const rotation = 360 - sunAzimuth;

        compassDial.style.transform = `rotate(${rotation}deg)`;
        
        // In Sun mode, we assume user is pointing correctly, so we don't show degree numbers dynamically
        // But we can show what degree the sun is at
        degreeVal.innerText = "Sun";
        dirText.innerText = "Pos";
    }

    // --- INITIALIZATION ---
    
    // Check Permissions for iOS 13+
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
        iosBtn.style.display = 'block';
        iosBtn.addEventListener('click', () => {
            DeviceOrientationEvent.requestPermission()
                .then(response => {
                    if (response === 'granted') {
                        iosBtn.style.display = 'none';
                        window.addEventListener('deviceorientation', handleOrientation, true);
                    } else {
                        alert("Permission denied. Switching to Sun Mode.");
                        enableSunMode();
                    }
                })
                .catch(() => enableSunMode());
        });
    } else {
        // Standard non-permission based or Android
        if (window.DeviceOrientationEvent) {
            window.addEventListener('deviceorientationabsolute', handleOrientation, true); // Android chrome
            window.addEventListener('deviceorientation', handleOrientation, true); // Standard fallback
            
            // Check if sensors are actually returning data after 1 second
            setTimeout(() => {
                const testVal = degreeVal.innerText;
                if(testVal === "0" && !isSunMode) {
                    // Likely no sensor hardware found
                    // enableSunMode(); // Optional: Auto switch. 
                    // Let's keep it manual via button or if explicitly failed, 
                    // but usually event fires with nulls if no sensor.
                }
            }, 1000);
        } else {
            enableSunMode();
        }
    }
    
    // Global function to force switch (exposed to window for button click)
    window.forceSunMode = function() {
        if(confirm("Force Sun Mode? Use this if your device lacks a magnetometer.")) {
            window.removeEventListener('deviceorientation', handleOrientation);
            window.removeEventListener('deviceorientationabsolute', handleOrientation);
            enableSunMode();
        }
    }

})();