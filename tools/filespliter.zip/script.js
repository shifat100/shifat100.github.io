var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Design ---
var toolHTML = `
<style>
    .merge-box { background: #fff; padding: 15px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .controls { display: flex; flex-direction: column; gap: 10px; margin: 10px 0; text-align: left; }
    input[type="text"] { padding: 10px; border: 1px solid #ddd; border-radius: 4px; width: 100%; box-sizing: border-box; }
    
    .file-area { 
        border: 2px dashed #28a745; 
        padding: 20px; 
        text-align: center; 
        border-radius: 5px; 
        cursor: pointer; 
        background: #f8f9fa; 
        transition: 0.3s;
    }
    .file-area:hover { background: #e2e6ea; border-color: #218838; }
    
    .extracted-list { list-style: none; padding: 0; margin: 15px 0; text-align: left; }
    .extracted-card { background: #fdfdfd; border: 1px solid #e0e0e0; margin-bottom: 15px; padding: 12px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); }
    .card-header { display: flex; justify-content: space-between; align-items: center; font-weight: bold; margin-bottom: 8px; word-break: break-all; }
    .card-actions { display: flex; gap: 5px; flex-shrink: 0; }
    
    .btn-action { border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 13px; font-weight: bold; color: white; }
    .btn-copy { background: #17a2b8; }
    .btn-download { background: #28a745; }
    
    textarea.preview-box { width: 100%; height: 100px; padding: 8px; border: 1px solid #ccc; border-radius: 4px; font-family: monospace; font-size: 13px; box-sizing: border-box; resize: vertical; }

    label { font-weight: bold; font-size: 14px; color: #555; }
    small { color: #777; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>File Splitter & Extractor Pro</h1>
    
    <div class="merge-box">
        
        <!-- Settings -->
        <div class="controls">
            <div>
                <label>Divider Pattern used during Merge:</label>
                <input type="text" id="dividerTemplate" value="--- START: {filename} ---">
                <small>Use <code>{filename}</code> tag to detect individual files properly.</small>
            </div>
        </div>

        <!-- File Upload Area -->
        <div class="file-area" onclick="document.getElementById('mergedFileInput').click()">
            <font style="font-size:30px">📂</font><br>
            <b>Select Merged File</b><br>
            <small>(Upload the file you want to split/view)</small>
            <input type="file" id="mergedFileInput" style="display: none;" onchange="processMergedFile(this)">
        </div>

        <div id="status" style="margin-top:10px; font-weight:bold;"></div>

        <!-- Extracted Files List -->
        <div id="extractedContainer" style="display:none; margin-top: 20px;">
            <h3>Extracted Files (<span id="fileCount">0</span>)</h3>
            <div id="extractedList" class="extracted-list"></div>
        </div>

    </div>
</center>
`;

app.innerHTML = toolHTML;

// --- Global Variables ---
window.extractedFiles = [];

// --- Functions ---

// 1. Handle & Read File
window.processMergedFile = function(input) {
    var file = input.files[0];
    if (!file) return;

    var status = document.getElementById('status');
    var template = document.getElementById('dividerTemplate').value;

    if (!template.includes('{filename}')) {
        alert("Divider Pattern must contain '{filename}'!");
        return;
    }

    status.style.color = "#007bff";
    status.innerText = "Processing file... Please wait.";

    var reader = new FileReader();
    reader.onload = function(e) {
        var content = e.target.result;
        parseAndExtract(content, template);
    };
    reader.onerror = function() {
        status.style.color = "red";
        status.innerText = "❌ Error reading file!";
    };

    reader.readAsText(file);
    input.value = '';
};

// 2. Parse & Unmerge Text
function parseAndExtract(content, template) {
    var status = document.getElementById('status');
    
    try {
        var normalizedTemplate = template.replace(/\\n/g, '\n');
        var escapedTemplate = normalizedTemplate.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
        var regexPattern = escapedTemplate.replace('\\{filename\\}', '([^\r\n]+)');

        var regex = new RegExp(regexPattern, 'g');
        var matches = [];
        var match;

        while ((match = regex.exec(content)) !== null) {
            matches.push({
                filename: match[1].trim(),
                dividerStart: match.index,
                contentStart: match.index + match[0].length
            });
        }

        if (matches.length === 0) {
            status.style.color = "#dc3545";
            status.innerText = "⚠️ No files found! Please check if your Divider Pattern matches the file text.";
            document.getElementById('extractedContainer').style.display = 'none';
            return;
        }

        window.extractedFiles = [];

        for (var i = 0; i < matches.length; i++) {
            var filename = matches[i].filename;
            var start = matches[i].contentStart;
            var end = (i + 1 < matches.length) ? matches[i + 1].dividerStart : content.length;

            var fileData = content.substring(start, end).trim();

            window.extractedFiles.push({
                name: filename,
                content: fileData
            });
        }

        renderExtractedFiles();
        status.style.color = "#28a745";
        status.innerText = "✅ Extraction complete!";

    } catch (err) {
        console.error(err);
        status.style.color = "red";
        status.innerText = "❌ Error: " + err.message;
    }
}

// 3. Render List UI
function renderExtractedFiles() {
    var container = document.getElementById('extractedContainer');
    var list = document.getElementById('extractedList');
    var count = document.getElementById('fileCount');

    count.innerText = window.extractedFiles.length;
    list.innerHTML = '';
    container.style.display = 'block';

    window.extractedFiles.forEach((file, index) => {
        var card = document.createElement('div');
        card.className = 'extracted-card';

        card.innerHTML = `
            <div class="card-header">
                <span>📄 ${index + 1}. ${escapeHtml(file.name)}</span>
                <div class="card-actions">
                    <button class="btn-action btn-copy" onclick="copyContent(${index}, this)">📋 Copy</button>
                    <button class="btn-action btn-download" onclick="downloadSingleFile(${index})">⬇ Download</button>
                </div>
            </div>
            <textarea class="preview-box" readonly>${escapeHtml(file.content)}</textarea>
        `;

        list.appendChild(card);
    });
}

// 4. Action: Copy
window.copyContent = function(index, btn) {
    var file = window.extractedFiles[index];
    navigator.clipboard.writeText(file.content).then(() => {
        var originalText = btn.innerText;
        btn.innerText = "✅ Copied!";
        btn.style.background = "#28a745";
        setTimeout(() => {
            btn.innerText = originalText;
            btn.style.background = "#17a2b8";
        }, 2000);
    }).catch(() => {
        alert("Failed to copy content.");
    });
};

// 5. Action: Download
window.downloadSingleFile = function(index) {
    var file = window.extractedFiles[index];
    var blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    
    var downloadName = file.name.split('/').pop().split('\\').pop();

    var link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = downloadName || `extracted_file_${index + 1}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// Helper: Escape HTML
function escapeHtml(text) {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}