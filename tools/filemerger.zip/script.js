var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Design ---
var toolHTML = `
<style>
    .merge-box { background: #fff; padding: 15px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .controls { display: flex; flex-direction: column; gap: 10px; margin: 10px 0; text-align: left; }
    input[type="text"], select { padding: 10px; border: 1px solid #ddd; border-radius: 4px; width: 100%; box-sizing: border-box; }
    
    .upload-options { display: flex; gap: 10px; margin-bottom: 15px; }
    
    .file-area { 
        flex: 1;
        border: 2px dashed #007bff; 
        padding: 15px; 
        text-align: center; 
        border-radius: 5px; 
        cursor: pointer; 
        background: #f8f9fa; 
        transition: 0.3s;
    }
    .file-area:hover { background: #e2e6ea; border-color: #0056b3; }
    
    .file-list { list-style: none; padding: 0; margin: 10px 0; max-height: 200px; overflow-y: auto; text-align: left; }
    .file-item { background: #eee; margin-bottom: 5px; padding: 8px; border-radius: 4px; font-size: 14px; display: flex; justify-content: space-between; }
    .remove-file { color: red; cursor: pointer; font-weight: bold; }

    .btn-primary { background: #007bff; color: white; border: none; padding: 12px; border-radius: 5px; cursor: pointer; width: 100%; font-size: 16px; margin-top: 10px; }
    .btn-warning { background: #ffc107; color: #333; border: none; padding: 10px; border-radius: 5px; cursor: pointer; margin-top: 5px; }
    
    label { font-weight: bold; font-size: 14px; color: #555; }
    small { color: #777; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>File Merger Pro</h1>
    
    <div class="merge-box">
        
        <!-- Settings -->
        <div class="controls">
            <div>
                <label>Merge Mode:</label>
                <select id="mergeMode">
                    <option value="text">Text Mode (Txt, Code, Logs)</option>
                    <option value="binary">Binary Mode (Audio, Video, Images)</option>
                </select>
            </div>

            <div>
                <label>Filter Extension (Optional):</label>
                <input type="text" id="extFilter" placeholder="e.g. .txt, .mp3 (Leave empty for all)">
            </div>

            <div id="dividerBox">
                <label>Divider / Separator:</label>
                <input type="text" id="dividerInput" value="\n--- START: {filename} ---\n">
                <small>Will be inserted between files in both modes.</small>
            </div>
        </div>

        <!-- File Upload Area -->
        <div class="upload-options">
            <div class="file-area" onclick="document.getElementById('fileInput').click()">
                <font style="font-size:24px">📄</font><br>
                <b>Select Files</b><br>
                <small>(Multi-select)</small>
                <input type="file" id="fileInput" multiple style="display: none;" onchange="handleFiles(this)">
            </div>

            <div class="file-area" onclick="document.getElementById('folderInput').click()">
                <font style="font-size:24px">📂</font><br>
                <b>Select Folder</b><br>
                <small>(Entire Folder)</small>
                <input type="file" id="folderInput" webkitdirectory directory multiple style="display: none;" onchange="handleFiles(this)">
            </div>
        </div>

        <!-- Selected Files List -->
        <div id="fileListContainer" style="display:none;">
            <h4>Selected Files (<span id="fileCount">0</span>)</h4>
            <ul id="fileList" class="file-list"></ul>
            <button class="btn-warning" onclick="clearFiles()">Clear All</button>
        </div>

        <!-- Action Button -->
        <button class="btn-primary" onclick="mergeFiles()">⚡ Merge & Download</button>
        <div id="status" style="margin-top:10px; font-weight:bold;"></div>

    </div>
</center>
`;

app.innerHTML = toolHTML;

// --- Global Variables ---
window.selectedFiles = [];

// --- Functions ---

// 1. Handle File Selection
window.handleFiles = function(input) {
    var files = Array.from(input.files);
    var filter = document.getElementById('extFilter').value.trim().toLowerCase();
    
    // Sort by name
    files.sort((a, b) => a.name.localeCompare(b.name));

    files.forEach(file => {
        if (file.name === '.DS_Store' || file.name === 'Thumbs.db') return;
        if (filter) {
            var ext = "." + file.name.split('.').pop().toLowerCase();
            if (!filter.includes(ext)) return; 
        }
        window.selectedFiles.push(file);
    });

    renderFileList();
    input.value = ''; 
};

// 2. Render List
window.renderFileList = function() {
    var list = document.getElementById('fileList');
    var container = document.getElementById('fileListContainer');
    document.getElementById('fileCount').innerText = window.selectedFiles.length;
    
    list.innerHTML = '';
    
    if (window.selectedFiles.length > 0) {
        container.style.display = 'block';
        window.selectedFiles.forEach((file, index) => {
            var li = document.createElement('li');
            li.className = 'file-item';
            var displayName = file.webkitRelativePath || file.name;
            li.innerHTML = `<span>${index + 1}. ${displayName}</span> <span class="remove-file" onclick="removeFile(${index})">&times;</span>`;
            list.appendChild(li);
        });
    } else {
        container.style.display = 'none';
    }
};

window.removeFile = function(index) {
    window.selectedFiles.splice(index, 1);
    renderFileList();
};

window.clearFiles = function() {
    window.selectedFiles = [];
    renderFileList();
};

// 3. Merge Logic (Supports Divider in Both Modes)
window.mergeFiles = async function() {
    if (window.selectedFiles.length === 0) {
        alert("Please select files first!");
        return;
    }

    var mode = document.getElementById('mergeMode').value;
    var dividerTemplate = document.getElementById('dividerInput').value;
    var status = document.getElementById('status');
    status.innerText = "Merging... Please wait.";

    try {
        var finalBlob;
        var resultParts = [];
        var encoder = new TextEncoder(); // For binary divider encoding

        for (const file of window.selectedFiles) {
            var displayName = file.webkitRelativePath || file.name;
            
            // 1. Prepare Divider
            var divider = dividerTemplate
                .replace(/\\n/g, '\n') 
                .replace('{filename}', displayName);
            
            // 2. Add Divider
            if (mode === 'text') {
                resultParts.push(divider);
            } else {
                // In binary mode, convert string divider to Uint8Array
                resultParts.push(encoder.encode(divider));
            }

            // 3. Add File Content
            if (mode === 'text') {
                const text = await readFileAsText(file);
                resultParts.push(text);
                resultParts.push('\n'); // Extra newline for safety
            } else {
                const buffer = await readFileAsArrayBuffer(file);
                resultParts.push(buffer);
                // Optional: Add newline byte in binary mode if needed, usually ignored by players but good for separation
                // resultParts.push(encoder.encode('\n')); 
            }
        }

        // 4. Create Blob
        if (mode === 'text') {
            finalBlob = new Blob(resultParts, { type: 'text/plain' });
        } else {
            var mimeType = window.selectedFiles[0].type || 'application/octet-stream';
            finalBlob = new Blob(resultParts, { type: mimeType });
        }

        // 5. Download
        var ext = mode === 'text' ? '.txt' : '.merged';
        if(mode === 'binary' && window.selectedFiles.length > 0) {
            var parts = window.selectedFiles[0].name.split('.');
            if(parts.length > 1) ext = '.' + parts.pop();
        }

        var downloadLink = document.createElement('a');
        downloadLink.href = URL.createObjectURL(finalBlob);
        downloadLink.download = "merged_output" + ext;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        status.innerText = "Done! Download started.";

    } catch (e) {
        console.error(e);
        status.innerText = "Error merging files!";
        alert("An error occurred during merging.");
    }
};

// Helpers
function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsText(file);
    });
}

function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
    });
}