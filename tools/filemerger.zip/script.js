var app = document.getElementById('container');
app.innerHTML = '';

// --- UI Design ---
var toolHTML = `
<style>
    .merge-box { background: #fff; padding: 15px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .controls { display: flex; flex-direction: column; gap: 10px; margin: 10px 0; text-align: left; }
    input[type="text"], select { padding: 10px; border: 1px solid #ddd; border-radius: 4px; width: 100%; box-sizing: border-box; }
    
    /* Upload Buttons Container */
    .upload-options { display: flex; gap: 10px; margin-bottom: 15px; }
    
    .file-area { 
        flex: 1;
        border: 2px dashed #007bff; 
        padding: 15px; 
        text-align: center; 
        border-radius: 5px; 
        cursor: pointer; 
        background: #f8f9fa; 
        transition: 0.3s;
    }
    .file-area:hover { background: #e2e6ea; border-color: #0056b3; }
    .file-area i { font-size: 24px; color: #007bff; margin-bottom: 5px; display: block; }
    
    .file-list { list-style: none; padding: 0; margin: 10px 0; max-height: 200px; overflow-y: auto; text-align: left; }
    .file-item { background: #eee; margin-bottom: 5px; padding: 8px; border-radius: 4px; font-size: 14px; display: flex; justify-content: space-between; }
    .remove-file { color: red; cursor: pointer; font-weight: bold; }

    .btn-primary { background: #007bff; color: white; border: none; padding: 12px; border-radius: 5px; cursor: pointer; width: 100%; font-size: 16px; margin-top: 10px; }
    .btn-warning { background: #ffc107; color: #333; border: none; padding: 10px; border-radius: 5px; cursor: pointer; margin-top: 5px; }
    
    label { font-weight: bold; font-size: 14px; color: #555; }
    small { color: #777; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>File Merger Pro</h1>
    
    <div class="merge-box">
        
        <!-- Settings -->
        <div class="controls">
            <div>
                <label>Merge Mode:</label>
                <select id="mergeMode" onchange="toggleDivider()">
                    <option value="text">Text Mode (Code, Logs, TXT) - Supports Dividers</option>
                    <option value="binary">Binary Mode (Audio, Video, Images) - No Dividers</option>
                </select>
            </div>

            <div>
                <label>Filter Extension (Optional):</label>
                <input type="text" id="extFilter" placeholder="e.g. .txt, .js (Leave empty for all)">
                <small>Required for folders (e.g., if you only want .mp3 from a folder)</small>
            </div>

            <div id="dividerBox">
                <label>Divider / Separator:</label>
                <input type="text" id="dividerInput" value="\n--- START: {filename} ---\n">
            </div>
        </div>

        <!-- File Upload Area (Two Buttons) -->
        <div class="upload-options">
            
            <!-- Option 1: Multiple Files -->
            <div class="file-area" onclick="document.getElementById('fileInput').click()">
                <font style="font-size:24px">📄</font><br>
                <b>Select Files</b><br>
                <small>(Multi-select)</small>
                <input type="file" id="fileInput" multiple style="display: none;" onchange="handleFiles(this)">
            </div>

            <!-- Option 2: Folder -->
            <div class="file-area" onclick="document.getElementById('folderInput').click()">
                <font style="font-size:24px">📂</font><br>
                <b>Select Folder</b><br>
                <small>(Entire Folder)</small>
                <!-- webkitdirectory allows folder selection -->
                <input type="file" id="folderInput" webkitdirectory directory multiple style="display: none;" onchange="handleFiles(this)">
            </div>

        </div>

        <!-- Selected Files List -->
        <div id="fileListContainer" style="display:none;">
            <h4>Selected Files (<span id="fileCount">0</span>)</h4>
            <ul id="fileList" class="file-list"></ul>
            <button class="btn-warning" onclick="clearFiles()">Clear All</button>
        </div>

        <!-- Action Button -->
        <button class="btn-primary" onclick="mergeFiles()">⚡ Merge & Download</button>
        <div id="status" style="margin-top:10px; font-weight:bold;"></div>

    </div>
</center>
`;

app.innerHTML = toolHTML;

// --- Global Variables ---
window.selectedFiles = [];

// --- Functions ---

// 1. Toggle Divider Input based on Mode
window.toggleDivider = function() {
    var mode = document.getElementById('mergeMode').value;
    var divBox = document.getElementById('dividerBox');
    if (mode === 'binary') {
        divBox.style.display = 'none';
        alert("Binary Mode selected. Dividers disabled to prevent file corruption.");
    } else {
        divBox.style.display = 'block';
    }
};

// 2. Handle File Selection (Works for both Files and Folders)
window.handleFiles = function(input) {
    var files = Array.from(input.files);
    var filter = document.getElementById('extFilter').value.trim().toLowerCase();
    
    // Sort files by name to ensure folder contents are in order
    files.sort((a, b) => a.name.localeCompare(b.name));

    var addedCount = 0;

    files.forEach(file => {
        // Skip system files often found in folders
        if (file.name === '.DS_Store' || file.name === 'Thumbs.db') return;

        // Extension Filter Logic
        if (filter) {
            var ext = "." + file.name.split('.').pop().toLowerCase();
            // Handle multiple filters e.g., ".html, .css"
            if (!filter.includes(ext)) return; 
        }
        
        window.selectedFiles.push(file);
        addedCount++;
    });

    if(addedCount === 0 && files.length > 0 && filter !== "") {
        alert("No files matched your extension filter!");
    }

    renderFileList();
    input.value = ''; // Reset input
};

// 3. Render the list of files
window.renderFileList = function() {
    var list = document.getElementById('fileList');
    var container = document.getElementById('fileListContainer');
    var countSpan = document.getElementById('fileCount');
    
    list.innerHTML = '';
    
    if (window.selectedFiles.length > 0) {
        container.style.display = 'block';
        countSpan.innerText = window.selectedFiles.length;

        window.selectedFiles.forEach((file, index) => {
            var li = document.createElement('li');
            li.className = 'file-item';
            // Show relative path if available (common in folder upload), else name
            var displayName = file.webkitRelativePath || file.name;
            
            li.innerHTML = `
                <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:85%;">${index + 1}. ${displayName}</span>
                <span class="remove-file" onclick="removeFile(${index})">&times;</span>
            `;
            list.appendChild(li);
        });
    } else {
        container.style.display = 'none';
    }
};

// 4. Remove a single file
window.removeFile = function(index) {
    window.selectedFiles.splice(index, 1);
    renderFileList();
};

// 5. Clear all files
window.clearFiles = function() {
    window.selectedFiles = [];
    renderFileList();
};

// 6. Merge Logic
window.mergeFiles = async function() {
    if (window.selectedFiles.length === 0) {
        alert("Please select files first!");
        return;
    }

    var mode = document.getElementById('mergeMode').value;
    var dividerTemplate = document.getElementById('dividerInput').value;
    var status = document.getElementById('status');
    status.innerText = "Merging... Please wait.";

    try {
        var finalBlob;
        var resultParts = [];

        // TEXT MODE MERGE
        if (mode === 'text') {
            for (const file of window.selectedFiles) {
                const text = await readFileAsText(file);
                
                var displayName = file.webkitRelativePath || file.name;
                var divider = dividerTemplate
                    .replace(/\\n/g, '\n') 
                    .replace('{filename}', displayName); 
                
                resultParts.push(divider);
                resultParts.push(text);
                resultParts.push('\n'); 
            }
            finalBlob = new Blob(resultParts, { type: 'text/plain' });
        } 
        
        // BINARY MODE MERGE
        else {
            for (const file of window.selectedFiles) {
                const buffer = await readFileAsArrayBuffer(file);
                resultParts.push(buffer);
            }
            var mimeType = window.selectedFiles[0].type || 'application/octet-stream';
            finalBlob = new Blob(resultParts, { type: mimeType });
        }

        // Trigger Download
        var ext = mode === 'text' ? '.txt' : '.merged';
        if(mode === 'binary' && window.selectedFiles.length > 0) {
            var parts = window.selectedFiles[0].name.split('.');
            if(parts.length > 1) ext = '.' + parts.pop();
        }

        var downloadLink = document.createElement('a');
        downloadLink.href = URL.createObjectURL(finalBlob);
        downloadLink.download = "merged_output" + ext;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        document.body.removeChild(downloadLink);
        
        status.innerText = "Done! Download started.";

    } catch (e) {
        console.error(e);
        status.innerText = "Error merging files!";
        alert("An error occurred during merging.");
    }
};

// Helper: Read as Text
function readFileAsText(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsText(file);
    });
}

// Helper: Read as ArrayBuffer (Binary)
function readFileAsArrayBuffer(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsArrayBuffer(file);
    });
}