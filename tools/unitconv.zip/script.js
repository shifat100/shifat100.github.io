var app = document.getElementById('container');
app.innerHTML = '';

var toolHTML = `
<style>
    .conv-box { background: #fff; padding: 20px; border-radius: 8px; margin: 10px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .input-group { margin-bottom: 15px; text-align: left; }
    .input-group label { display: block; font-weight: bold; margin-bottom: 5px; }
    .input-field, .select-field { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
    .action-btn { width: 100%; padding: 12px; background: #28a745; color: white; border: none; border-radius: 5px; font-size: 16px; cursor: pointer; }
    .result-display { margin-top: 20px; font-size: 18px; font-weight: bold; color: #333; background: #e9ecef; padding: 10px; border-radius: 5px; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>Unit Converter</h1>
    <div class="conv-box">
        <div class="input-group">
            <label>Conversion Type:</label>
            <select id="convType" class="select-field" onchange="updateLabels()">
                <option value="m_to_ft">Meters to Feet</option>
                <option value="ft_to_m">Feet to Meters</option>
                <option value="kg_to_lb">Kg to Pounds</option>
                <option value="lb_to_kg">Pounds to Kg</option>
            </select>
        </div>
        
        <div class="input-group">
            <label id="inputLabel">Enter Meters:</label>
            <input type="number" id="inputValue" class="input-field" placeholder="0">
        </div>

        <button onclick="convertUnit()" class="action-btn">Convert</button>
        
        <div id="result" class="result-display" style="display:none;"></div>
    </div>
</center>
`;

app.innerHTML = toolHTML;

window.updateLabels = function() {
    var type = document.getElementById('convType').value;
    var label = document.getElementById('inputLabel');
    if(type === 'm_to_ft') label.innerText = 'Enter Meters:';
    else if(type === 'ft_to_m') label.innerText = 'Enter Feet:';
    else if(type === 'kg_to_lb') label.innerText = 'Enter Kilograms:';
    else if(type === 'lb_to_kg') label.innerText = 'Enter Pounds:';
    
    document.getElementById('result').style.display = 'none';
};

window.convertUnit = function() {
    var val = parseFloat(document.getElementById('inputValue').value);
    var type = document.getElementById('convType').value;
    var resBox = document.getElementById('result');
    
    if (isNaN(val)) {
        alert("Please enter a valid number");
        return;
    }

    var result = 0;
    var unit = "";

    if (type === 'm_to_ft') { result = val * 3.28084; unit = "ft"; }
    else if (type === 'ft_to_m') { result = val / 3.28084; unit = "m"; }
    else if (type === 'kg_to_lb') { result = val * 2.20462; unit = "lbs"; }
    else if (type === 'lb_to_kg') { result = val / 2.20462; unit = "kg"; }

    resBox.style.display = 'block';
    resBox.innerHTML = val + " = " + result.toFixed(2) + " " + unit;
};