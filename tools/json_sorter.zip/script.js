// Global State for this tool instance
var sorterState = {
    registry: {},
    activeCatId: null,
    draggedId: null
};

// 1. Inject CSS
var sorterStyles = `
    #sorter-app {
        display: flex;
        flex-direction: column;
        height: 100%; /* Fill container */
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        background: #f8fafc;
        color: #334155;
    }

    /* Header & Controls */
    .sorter-header {
        padding: 15px;
        background: #fff;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
        align-items: center;
        flex-shrink: 0;
    }

    .header-title-row {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 10px;
    }

    .back-btn {
        background: transparent;
        border: 1px solid #cbd5e1;
        padding: 5px 10px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 0.9rem;
        color: #64748b;
    }
    .back-btn:hover { background: #f1f5f9; color: #333; }

    .control-row {
        display: flex;
        gap: 8px;
        width: 100%;
        align-items: center;
    }

    input[type="text"], input[type="file"] {
        padding: 8px;
        border: 1px solid #cbd5e1;
        border-radius: 6px;
        font-size: 14px;
    }
    input[type="text"] { flex: 1; }

    .btn-primary {
        background: #3b82f6;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 500;
        white-space: nowrap;
    }
    .btn-primary:hover { background: #2563eb; }

    .btn-secondary {
        background: #64748b;
        color: white;
        border: none;
        padding: 6px 12px;
        border-radius: 4px;
        cursor: pointer;
        font-size: 0.85rem;
    }

    /* Workspace Layout */
    .workspace {
        display: flex;
        flex: 1;
        overflow: hidden;
        position: relative;
    }

    /* Sidebar (Unassigned) */
    .sidebar {
        width: 300px;
        background: #f1f5f9;
        border-right: 1px solid #e2e8f0;
        display: flex;
        flex-direction: column;
        flex-shrink: 0;
    }
    
    .sidebar-head {
        padding: 10px;
        background: #e2e8f0;
        font-size: 0.85rem;
        font-weight: bold;
        text-transform: uppercase;
        color: #475569;
        display: flex;
        justify-content: space-between;
    }

    /* Main Area (Categories) */
    .main-area {
        flex: 1;
        display: flex;
        flex-direction: column;
        background: #fff;
        min-width: 0; /* Fix flex overflow */
    }

    /* Tabs */
    .tab-scroll {
        display: flex;
        overflow-x: auto;
        background: #f8fafc;
        border-bottom: 1px solid #e2e8f0;
        padding: 0 5px;
        scrollbar-width: thin;
    }

    .tab {
        padding: 10px 15px;
        margin-top: 5px;
        cursor: pointer;
        border: 1px solid transparent;
        border-bottom: none;
        border-radius: 6px 6px 0 0;
        color: #64748b;
        font-size: 0.9rem;
        display: flex;
        align-items: center;
        gap: 8px;
        white-space: nowrap;
    }
    
    .tab.active {
        background: #fff;
        color: #3b82f6;
        border-color: #e2e8f0;
        border-bottom-color: #fff;
        font-weight: 600;
        margin-bottom: -1px;
        z-index: 2;
    }

    .tab-close {
        font-size: 14px;
        width: 18px;
        height: 18px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
    }
    .tab-close:hover { background: #fee2e2; color: #ef4444; }

    /* Drop Zones */
    .drop-container {
        flex: 1;
        overflow-y: auto;
        padding: 15px;
        position: relative;
        transition: background 0.2s;
    }
    .drop-container.drag-over {
        background: rgba(59, 130, 246, 0.05);
        box-shadow: inset 0 0 0 2px #3b82f6;
    }

    /* Cards */
    .json-card {
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 10px;
        margin-bottom: 8px;
        box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        cursor: grab;
        font-size: 0.85rem;
        user-select: none;
    }
    .json-card:active { cursor: grabbing; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    
    .card-key { color: #3b82f6; font-weight: 600; margin-bottom: 4px; display: block; }
    .card-preview {
        color: #64748b;
        font-family: monospace;
        font-size: 0.75rem;
        white-space: pre-wrap;
        overflow: hidden;
        max-height: 3.6em; /* 3 lines */
        display: -webkit-box;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
    }

    /* Utilities */
    .badge { background: #94a3b8; color: white; padding: 1px 6px; border-radius: 10px; font-size: 0.75rem; }
    .empty-state {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100%;
        color: #94a3b8;
        text-align: center;
        padding: 20px;
    }
    .toolbar-active {
        padding: 8px 15px;
        border-bottom: 1px solid #f1f5f9;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    /* Responsive */
    @media (max-width: 700px) {
        .workspace { flex-direction: column; }
        .sidebar { width: 100%; height: 35%; border-right: none; border-bottom: 1px solid #e2e8f0; }
        .main-area { height: 65%; }
        .control-row { flex-wrap: wrap; }
    }
`;

// 2. Render UI
var container = document.getElementById('container');
var styleEl = document.createElement('style');
styleEl.innerHTML = sorterStyles;
document.head.appendChild(styleEl);

container.innerHTML = `
<div id="sorter-app">
    <div class="sorter-header">
        <div class="header-title-row">
            <h3 style="margin:0">JSON Sorter</h3>
            <button class="back-btn" onclick="location.reload()">Back</button>
        </div>
        <div class="control-row">
            <input type="file" id="srt-file" accept=".json" style="max-width: 200px;">
            <input type="text" id="srt-cat-name" placeholder="New Category Name">
            <button class="btn-primary" id="srt-add-btn">Add Category</button>
        </div>
    </div>

    <div class="workspace">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-head">
                <span>Unassigned</span>
                <span id="srt-pool-count" class="badge">0</span>
            </div>
            <div id="pool-zone" class="drop-container">
                <div class="empty-state">Upload JSON to start</div>
            </div>
        </div>

        <!-- Main Area -->
        <div class="main-area">
            <div class="tab-scroll" id="srt-tabs"></div>
            
            <div id="active-toolbar" class="toolbar-active" style="display:none">
                <strong id="active-cat-label" style="font-size:0.9rem">Category</strong>
                <div>
                    <button class="btn-secondary" id="btn-dl-curr">Download This</button>
                    <button class="btn-secondary" id="btn-dl-all">Download All</button>
                </div>
            </div>

            <div id="category-viewport" style="flex:1; position:relative; overflow:hidden;">
                <div id="start-msg" class="empty-state">Create a category to begin sorting</div>
            </div>
        </div>
    </div>
</div>
`;

// 3. Logic Implementation

// --- Helper Functions ---
function srtGenId() { return 'item_' + Math.random().toString(36).substr(2, 9); }
function srtUpdateCount() {
    const count = document.getElementById('pool-zone').querySelectorAll('.json-card').length;
    document.getElementById('srt-pool-count').innerText = count;
}

function srtCreateCard(id, data) {
    const div = document.createElement('div');
    div.className = 'json-card';
    div.id = id;
    div.draggable = true;

    // Try to find a meaningful label
    const keys = Object.keys(data);
    const labelKey = keys.find(k => /name|title|id|label|email/i.test(k)) || keys[0];
    const labelVal = data[labelKey] !== undefined ? data[labelKey] : 'Item';
    const jsonStr = JSON.stringify(data);

    div.innerHTML = `
        <span class="card-key">${labelKey}: ${String(labelVal).substring(0,30)}</span>
        <div class="card-preview">${jsonStr.substring(0, 150)}</div>
    `;

    // Event Listeners for Drag (Native HTML5)
    div.addEventListener('dragstart', (e) => {
        sorterState.draggedId = e.target.id;
        e.dataTransfer.setData('text/plain', e.target.id);
        e.dataTransfer.effectAllowed = "move";
        setTimeout(() => e.target.style.opacity = '0.5', 0);
    });

    div.addEventListener('dragend', (e) => {
        e.target.style.opacity = '1';
        sorterState.draggedId = null;
        document.querySelectorAll('.drop-container').forEach(el => el.classList.remove('drag-over'));
    });

    return div;
}

function srtSetupDropZone(el) {
    el.addEventListener('dragover', (e) => {
        e.preventDefault(); // Necessary for drop to work
        e.dataTransfer.dropEffect = "move";
        el.classList.add('drag-over');
    });

    el.addEventListener('dragleave', () => {
        el.classList.remove('drag-over');
    });

    el.addEventListener('drop', (e) => {
        e.preventDefault();
        el.classList.remove('drag-over');
        const id = e.dataTransfer.getData('text/plain');
        const card = document.getElementById(id);
        
        // Ensure we are dropping into a container, not onto another card
        if (card && el.classList.contains('drop-container')) {
            el.appendChild(card);
            srtUpdateCount();
        }
    });
}

// Initial setup for pool zone
srtSetupDropZone(document.getElementById('pool-zone'));

// --- File Upload ---
document.getElementById('srt-file').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = function(evt) {
        try {
            const json = JSON.parse(evt.target.result);
            const arr = Array.isArray(json) ? json : [json];
            
            const pool = document.getElementById('pool-zone');
            pool.innerHTML = ''; // Clear
            sorterState.registry = {}; // Reset DB

            arr.forEach(item => {
                const id = srtGenId();
                sorterState.registry[id] = item;
                pool.appendChild(srtCreateCard(id, item));
            });
            srtUpdateCount();
        } catch (err) {
            alert("Error parsing JSON");
        }
    };
    reader.readAsText(file);
});

// --- Category Management ---
document.getElementById('srt-add-btn').addEventListener('click', () => {
    const input = document.getElementById('srt-cat-name');
    const name = input.value.trim();
    if (!name) return;

    const catId = 'cat_' + Math.random().toString(36).substr(2, 5);
    
    // 1. Create Tab
    const tab = document.createElement('div');
    tab.className = 'tab';
    tab.id = 'tab_' + catId;
    tab.innerHTML = `<span>${name}</span> <span class="tab-close">×</span>`;
    
    // Tab Click (Switch)
    tab.addEventListener('click', (e) => {
        if(!e.target.classList.contains('tab-close')) srtSwitchCat(catId, name);
    });

    // Tab Close (Delete)
    tab.querySelector('.tab-close').addEventListener('click', (e) => {
        e.stopPropagation();
        if(confirm('Delete category? Items return to unassigned.')) {
            const zone = document.getElementById('zone_' + catId);
            const pool = document.getElementById('pool-zone');
            // Move items back
            while(zone.firstChild) pool.appendChild(zone.firstChild);
            
            zone.remove();
            tab.remove();
            
            if(sorterState.activeCatId === catId) {
                document.getElementById('active-toolbar').style.display = 'none';
                document.getElementById('start-msg').style.display = 'flex';
                sorterState.activeCatId = null;
            }
            srtUpdateCount();
        }
    });

    document.getElementById('srt-tabs').appendChild(tab);

    // 2. Create Drop Zone (Hidden initially)
    const zone = document.createElement('div');
    zone.className = 'drop-container';
    zone.id = 'zone_' + catId;
    zone.style.display = 'none';
    zone.dataset.name = name;
    
    srtSetupDropZone(zone);
    document.getElementById('category-viewport').appendChild(zone);

    input.value = '';
    srtSwitchCat(catId, name);
});

function srtSwitchCat(catId, name) {
    sorterState.activeCatId = catId;

    // Toggle Tabs
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab_' + catId).classList.add('active');

    // Toggle Zones
    const viewport = document.getElementById('category-viewport');
    Array.from(viewport.children).forEach(child => {
        if(child.id !== 'start-msg') child.style.display = 'none';
    });
    document.getElementById('start-msg').style.display = 'none';
    
    const activeZone = document.getElementById('zone_' + catId);
    activeZone.style.display = 'block';

    // Update Toolbar
    document.getElementById('active-toolbar').style.display = 'flex';
    document.getElementById('active-cat-label').innerText = name;
}

// --- Downloads ---
function srtDownload(items, filename) {
    if(!items || items.length === 0) return alert('Category is empty');
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(items, null, 2));
    const a = document.createElement('a');
    a.href = dataStr;
    a.download = filename + ".json";
    document.body.appendChild(a);
    a.click();
    a.remove();
}

document.getElementById('btn-dl-curr').addEventListener('click', () => {
    if(!sorterState.activeCatId) return;
    const zone = document.getElementById('zone_' + sorterState.activeCatId);
    const items = Array.from(zone.children).map(el => sorterState.registry[el.id]);
    srtDownload(items, zone.dataset.name);
});

document.getElementById('btn-dl-all').addEventListener('click', () => {
    const zones = document.querySelectorAll('#category-viewport .drop-container');
    let count = 0;
    zones.forEach((zone, idx) => {
        const items = Array.from(zone.children).map(el => sorterState.registry[el.id]);
        if(items.length > 0) {
            setTimeout(() => srtDownload(items, zone.dataset.name), idx * 500);
            count++;
        }
    });
    if(count === 0) alert("No populated categories to download.");
});