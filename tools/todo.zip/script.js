var app = document.getElementById('container');
app.innerHTML = '';

var toolHTML = `
<style>
    .todo-container { max-width: 400px; margin: 10px auto; }
    .input-row { display: flex; gap: 5px; margin-bottom: 20px; }
    .task-input { flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
    .add-btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 4px; cursor: pointer; }
    .task-list { list-style: none; padding: 0; text-align: left; }
    .task-item { background: #fff; border-bottom: 1px solid #eee; padding: 10px; display: flex; justify-content: space-between; align-items: center; }
    .del-btn { background: #dc3545; color: white; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; font-size: 12px; }
    .empty-msg { color: #777; font-style: italic; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>To-Do List</h1>
    <div class="todo-container">
        <div class="input-row">
            <input type="text" id="taskInput" class="task-input" placeholder="Add a new task...">
            <button onclick="addTask()" class="add-btn">Add</button>
        </div>
        <ul id="taskList" class="task-list">
            <li class="empty-msg" id="emptyMsg">No tasks added yet.</li>
        </ul>
    </div>
</center>
`;

app.innerHTML = toolHTML;

window.addTask = function() {
    var input = document.getElementById('taskInput');
    var list = document.getElementById('taskList');
    var emptyMsg = document.getElementById('emptyMsg');
    var text = input.value.trim();

    if (text === "") return;

    if (emptyMsg) {
        emptyMsg.style.display = 'none';
    }

    var li = document.createElement('li');
    li.className = 'task-item';
    
    // Task content
    li.innerHTML = `
        <span>${text}</span>
        <button class="del-btn" onclick="removeTask(this)">Delete</button>
    `;

    list.appendChild(li);
    input.value = ''; // Clear input
};

window.removeTask = function(btn) {
    var li = btn.parentElement;
    li.remove();
    
    var list = document.getElementById('taskList');
    if (list.children.length === 1 && list.children[0].id === 'emptyMsg') {
        document.getElementById('emptyMsg').style.display = 'block';
    } else if (list.children.length === 0) {
        // Re-create empty msg if needed, though usually it's just hidden
        list.innerHTML = '<li class="empty-msg" id="emptyMsg">No tasks added yet.</li>';
    }
};