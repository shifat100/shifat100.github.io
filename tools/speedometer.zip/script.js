(function() {
    const container = document.getElementById('container');
    let watchId = null;

    // CSS Styles
    const styles = `
        <style>
            @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css');
            @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap');
            @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap');

            .header {
                display: flex;
                align-items: center;
                padding: 15px;
                background-color: #f8f9fa;
                box-shadow: 0 2px 5px rgba(0,0,0,0.05);
                margin-bottom: 20px;
                font-family: 'Roboto', sans-serif;
            }
            .back-btn {
                font-size: 1.2rem;
                cursor: pointer;
                margin-right: 15px;
                color: #333;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                border-radius: 50%;
                transition: background 0.2s;
            }
            .back-btn:active {
                background-color: #e2e6ea;
            }
            .tool-title {
                font-size: 1.2rem;
                font-weight: 600;
                color: #2c3e50;
            }
            .speed-container {
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                padding: 20px;
                text-align: center;
                font-family: 'Roboto', sans-serif;
            }
            .gauge-outer {
                width: 280px;
                height: 280px;
                border-radius: 50%;
                background: conic-gradient(#4facfe 0%, #00f2fe 100%);
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 10px 30px rgba(79, 172, 254, 0.4);
                margin-bottom: 30px;
                position: relative;
            }
            .gauge-inner {
                width: 260px;
                height: 260px;
                background-color: #1a1a2e;
                border-radius: 50%;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                color: #fff;
            }
            .speed-value {
                font-family: 'Orbitron', sans-serif;
                font-size: 5rem;
                font-weight: 700;
                color: #00f2fe;
                line-height: 1;
                text-shadow: 0 0 10px rgba(0, 242, 254, 0.5);
            }
            .speed-unit {
                font-size: 1.2rem;
                color: #888;
                margin-top: 5px;
                text-transform: uppercase;
                letter-spacing: 2px;
            }
            .status-text {
                margin-top: 20px;
                font-size: 1rem;
                color: #555;
                background: #fff;
                padding: 10px 20px;
                border-radius: 20px;
                box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            }
            .info-box {
                margin-top: 30px;
                font-size: 0.9rem;
                color: #666;
                background: #eef2f5;
                padding: 15px;
                border-radius: 8px;
                max-width: 90%;
            }
            .pulse {
                animation: pulse-animation 2s infinite;
            }
            @keyframes pulse-animation {
                0% { box-shadow: 0 0 0 0 rgba(79, 172, 254, 0.4); }
                70% { box-shadow: 0 0 0 20px rgba(79, 172, 254, 0); }
                100% { box-shadow: 0 0 0 0 rgba(79, 172, 254, 0); }
            }
        </style>
    `;

    // HTML Structure
    const html = `
        <div class="header">
            <span class="back-btn" onclick="location.reload()">
                <i class="fa-solid fa-arrow-left"></i>
            </span>
            <span class="tool-title">GPS Speedometer</span>
        </div>

        <div class="speed-container">
            <div class="gauge-outer pulse" id="gaugeCircle">
                <div class="gauge-inner">
                    <span id="speedDisplay" class="speed-value">0</span>
                    <span class="speed-unit">KM/H</span>
                </div>
            </div>

            <div id="statusMsg" class="status-text">
                <i class="fa-solid fa-satellite-dish"></i> Searching for GPS signal...
            </div>

            <div class="info-box">
                <i class="fa-solid fa-circle-info"></i> For accurate speed, please move outdoors under open sky.
            </div>
        </div>
    `;

    // Inject styles and HTML
    container.innerHTML = styles + html;

    // Logic
    const speedDisplay = document.getElementById('speedDisplay');
    const statusMsg = document.getElementById('statusMsg');
    const gaugeCircle = document.getElementById('gaugeCircle');

    function updateSpeed(position) {
        // Speed is in meters/second (m/s). Convert to km/h by multiplying by 3.6
        let speedMs = position.coords.speed;
        
        // Sometimes speed is null if not moving or device can't determine
        if (speedMs === null || speedMs < 0) {
            speedMs = 0;
        }

        const speedKmh = (speedMs * 3.6).toFixed(1); // 1 decimal place

        speedDisplay.textContent = speedKmh;
        statusMsg.innerHTML = '<i class="fa-solid fa-satellite"></i> Connected - Tracking Speed';
        statusMsg.style.color = 'green';
        
        // Stop pulse animation when active to save battery/visual noise
        gaugeCircle.classList.remove('pulse');
    }

    function handleError(error) {
        gaugeCircle.classList.remove('pulse');
        gaugeCircle.style.background = 'conic-gradient(#ff5f6d 0%, #ffc371 100%)';
        
        switch(error.code) {
            case error.PERMISSION_DENIED:
                statusMsg.innerHTML = "❌ Location access denied.";
                break;
            case error.POSITION_UNAVAILABLE:
                statusMsg.innerHTML = "❌ Location information unavailable.";
                break;
            case error.TIMEOUT:
                statusMsg.innerHTML = "❌ GPS connection timed out.";
                break;
            default:
                statusMsg.innerHTML = "❌ An unknown error occurred.";
                break;
        }
        statusMsg.style.color = '#d63031';
    }

    // Options for high accuracy (critical for speedometer)
    const options = {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
    };

    // Start Watching
    if (navigator.geolocation) {
        watchId = navigator.geolocation.watchPosition(updateSpeed, handleError, options);
    } else {
        statusMsg.innerHTML = "Geolocation is not supported by this browser.";
    }

})();