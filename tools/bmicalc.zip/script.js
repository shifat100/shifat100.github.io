var app = document.getElementById('container');
app.innerHTML = '';

var toolHTML = `
<style>
    .bmi-card { background: white; padding: 25px; border-radius: 10px; margin: 15px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
    .form-group { margin-bottom: 15px; text-align: left; }
    .form-group label { display: block; margin-bottom: 5px; color: #555; }
    .form-control { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; font-size: 16px; }
    .calc-btn { width: 100%; padding: 12px; background: #6610f2; color: white; border: none; border-radius: 5px; font-size: 18px; cursor: pointer; margin-top: 10px; }
    .bmi-result { margin-top: 20px; padding: 15px; border-radius: 5px; display: none; }
</style>

<div class="closebar" style="text-align: left;">
    <div class="closebtn" onclick="tools()" style="width: 100px; cursor: pointer;">
        <font style="font-weight: bolder;font-size: 24px">&#8672;</font> 
        <font style="font-size:16px">Back</font>
    </div>
</div>

<center>
    <h1>BMI Calculator</h1>
    <div class="bmi-card">
        <div class="form-group">
            <label>Weight (kg):</label>
            <input type="number" id="weight" class="form-control" placeholder="e.g. 60">
        </div>
        <div class="form-group">
            <label>Height (cm):</label>
            <input type="number" id="height" class="form-control" placeholder="e.g. 170">
        </div>
        
        <button onclick="calculateBMI()" class="calc-btn">Calculate BMI</button>
        
        <div id="bmiOutput" class="bmi-result"></div>
    </div>
</center>
`;

app.innerHTML = toolHTML;

window.calculateBMI = function() {
    var weight = parseFloat(document.getElementById('weight').value);
    var heightCm = parseFloat(document.getElementById('height').value);
    var output = document.getElementById('bmiOutput');

    if (!weight || !heightCm || weight <= 0 || heightCm <= 0) {
        alert("Please enter valid positive numbers!");
        return;
    }

    // Convert cm to meters
    var heightM = heightCm / 100;
    
    // Formula: kg / m^2
    var bmi = weight / (heightM * heightM);
    bmi = bmi.toFixed(1);

    var status = "";
    var color = "";

    if (bmi < 18.5) {
        status = "Underweight";
        color = "#ffc107"; // Yellow
    } else if (bmi >= 18.5 && bmi < 24.9) {
        status = "Normal Weight";
        color = "#28a745"; // Green
    } else if (bmi >= 25 && bmi < 29.9) {
        status = "Overweight";
        color = "#fd7e14"; // Orange
    } else {
        status = "Obese";
        color = "#dc3545"; // Red
    }

    output.style.display = 'block';
    output.style.backgroundColor = '#f8f9fa';
    output.style.border = '2px solid ' + color;
    output.innerHTML = `
        <span style="font-size: 32px; font-weight: bold; color: ${color}">${bmi}</span><br>
        <span style="font-size: 18px; color: #333">Status: <b>${status}</b></span>
    `;
};