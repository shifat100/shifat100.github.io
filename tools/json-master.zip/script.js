// 1. Inject CSS
const style = document.createElement('style');
style.innerHTML = `
    :root {
        --json-bg: #1e1e1e;
        --json-panel: #252526;
        --json-border: #333;
        --json-accent: #007acc;
        --json-text: #d4d4d4;
        --json-err: #f44336;
    }
    #json-tool-wrapper {
        display: flex;
        flex-direction: column;
        height: 100%; /* Fill container */
        background: var(--json-bg);
        color: var(--json-text);
        font-family: 'Segoe UI', sans-serif;
        overflow: hidden;
    }
    .json-header {
        display: flex;
        align-items: center;
        padding: 10px;
        background: var(--json-panel);
        border-bottom: 1px solid var(--json-border);
        gap: 10px;
    }
    .json-header h2 { margin: 0; font-size: 1.1rem; flex: 1; }
    
    .json-main { display: flex; flex: 1; overflow: hidden; }
    
    /* Sidebar */
    .json-sidebar {
        width: 180px;
        background: #2d2d2d;
        border-right: 1px solid var(--json-border);
        display: flex;
        flex-direction: column;
        padding: 10px;
        overflow-y: auto;
        gap: 5px;
    }
    .json-sidebar button {
        background: transparent;
        border: 1px solid transparent;
        color: #ccc;
        padding: 8px;
        text-align: left;
        cursor: pointer;
        font-size: 0.85rem;
        border-radius: 3px;
    }
    .json-sidebar button:hover { background: #3e3e42; color: white; }
    .sb-group { font-size: 0.75rem; color: #666; font-weight: bold; margin-top: 10px; margin-bottom: 2px; text-transform: uppercase; }

    /* Workspace */
    .json-workspace { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .json-editors { flex: 1; display: flex; overflow: hidden; }
    .json-pane { flex: 1; display: flex; flex-direction: column; border-right: 1px solid var(--json-border); min-width: 0; }
    .json-pane:last-child { border-right: none; }
    
    .pane-head { 
        padding: 5px 10px; background: var(--json-panel); font-size: 0.8rem; color: #888; 
        display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--json-border);
    }
    
    textarea.json-input {
        flex: 1; background: var(--json-bg); color: #9cdcfe; border: none; 
        padding: 10px; resize: none; font-family: monospace; font-size: 13px; outline: none;
    }

    /* Views */
    #json-visual-view, #json-table-view { flex: 1; overflow: auto; padding: 10px; display: none; background: var(--json-bg); }
    
    /* Tree */
    .jk { color: #9cdcfe; } .js { color: #ce9178; } .jn { color: #b5cea8; } .jb { color: #569cd6; }
    .collapsible { cursor: pointer; user-select: none; }
    .collapsible::before { content: '▼ '; font-size: 0.7em; color: #888; }
    .collapsed::before { content: '▶ '; }
    .collapsed + ul { display: none; }
    ul.tree { list-style: none; padding-left: 15px; margin: 0; font-family: monospace; }

    /* Modal */
    .json-modal {
        position: fixed; top: 0; left: 0; width: 100%; height: 100%;
        background: rgba(0,0,0,0.5); z-index: 999; display: none;
        align-items: center; justify-content: center;
    }
    .json-modal-box {
        background: var(--json-panel); border: 1px solid var(--json-border);
        padding: 20px; width: 300px; border-radius: 5px;
        box-shadow: 0 4px 10px rgba(0,0,0,0.5);
    }
    .json-modal-box input { width: 100%; background: #333; border: 1px solid #444; color: white; padding: 5px; margin: 10px 0; }
    .json-btn-primary { background: var(--json-accent) !important; color: white !important; }

    /* Responsive */
    @media (max-width: 600px) {
        .json-editors { flex-direction: column; }
        .json-pane { height: 50%; }
        .json-sidebar { width: 60px; padding: 5px; }
        .sb-group, .btn-txt { display: none; }
        .json-sidebar button { text-align: center; }
    }
`;
document.head.appendChild(style);

// 2. Load JSZip dynamically for Split/Zip feature
if (typeof JSZip === 'undefined') {
    const script = document.createElement('script');
    script.src = "https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js";
    document.head.appendChild(script);
}

// 3. UI Template
const container = document.getElementById('container');
container.innerHTML = `
<div id="json-tool-wrapper">
    <div class="json-header">
        <button onclick="app.navigate('home')" style="background:none; border:none; color:white; font-size:1.2rem; cursor:pointer;">⬅</button>
        <h2>JSON Studio</h2>
        <input type="file" id="jsonFileLoad" multiple style="display:none">
        <button class="json-btn-primary" onclick="document.getElementById('jsonFileLoad').click()" style="padding:5px 10px; border-radius:4px; border:none; cursor:pointer;">📂 Load</button>
    </div>
    
    <div class="json-main">
        <div class="json-sidebar">
            <div class="sb-group">Format</div>
            <button onclick="JsonApp.process('prettify')">✨ <span class="btn-txt">Prettify</span></button>
            <button onclick="JsonApp.process('minify')">📦 <span class="btn-txt">Minify</span></button>
            
            <div class="sb-group">Data</div>
            <button onclick="JsonApp.process('sort')">📊 <span class="btn-txt">Sort Keys</span></button>
            <button onclick="JsonApp.process('dedupe')">🧹 <span class="btn-txt">Unique</span></button>
            <button onclick="JsonApp.modal('filter')">🔍 <span class="btn-txt">Filter</span></button>
            
            <div class="sb-group">Tools</div>
            <button onclick="JsonApp.modal('split')">✂️ <span class="btn-txt">Split (Zip)</span></button>
            <button onclick="JsonApp.process('combine')">🔗 <span class="btn-txt">Combine</span></button>
            
            <div class="sb-group">Convert</div>
            <button onclick="JsonApp.convert('xml')">📄 <span class="btn-txt">to XML</span></button>
            <button onclick="JsonApp.convert('csv')">📊 <span class="btn-txt">to CSV</span></button>
            <button onclick="JsonApp.convert('toml')">⚙️ <span class="btn-txt">to TOML</span></button>
            
            <div class="sb-group">View</div>
            <button onclick="JsonApp.setView('text')">📝 <span class="btn-txt">Text</span></button>
            <button onclick="JsonApp.setView('tree')">🌲 <span class="btn-txt">Tree</span></button>
        </div>
        
        <div class="json-workspace">
            <div class="json-editors">
                <div class="json-pane">
                    <div class="pane-head">
                        <span>INPUT</span> <span id="j-stats">0KB</span>
                    </div>
                    <textarea id="j-input" class="json-input" placeholder="Paste JSON here..."></textarea>
                </div>
                <div class="json-pane">
                    <div class="pane-head">
                        <span>OUTPUT</span>
                        <button onclick="JsonApp.download()" style="background:none; border:none; color:#aaa; cursor:pointer;">💾 Save</button>
                    </div>
                    <textarea id="j-output" class="json-input" readonly></textarea>
                    <div id="json-visual-view"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modals -->
<div id="m-split" class="json-modal">
    <div class="json-modal-box">
        <h3>Split & Zip</h3>
        <p>Items per file:</p>
        <input type="number" id="split-count" value="50">
        <div style="text-align:right; margin-top:10px;">
            <button onclick="JsonApp.closeModals()">Cancel</button>
            <button class="json-btn-primary" onclick="JsonApp.execSplit()">Download ZIP</button>
        </div>
    </div>
</div>

<div id="m-filter" class="json-modal">
    <div class="json-modal-box">
        <h3>Filter (JS Query)</h3>
        <p>e.g. <code>item.id > 100</code></p>
        <input type="text" id="filter-q" placeholder="item.active === true">
        <div style="text-align:right; margin-top:10px;">
            <button onclick="JsonApp.closeModals()">Cancel</button>
            <button class="json-btn-primary" onclick="JsonApp.execFilter()">Run</button>
        </div>
    </div>
</div>
`;

// 4. Logic Controller
window.JsonApp = {
    dom: {
        in: document.getElementById('j-input'),
        out: document.getElementById('j-output'),
        vis: document.getElementById('json-visual-view'),
        stats: document.getElementById('j-stats')
    },

    parse: function() {
        const raw = this.dom.in.value;
        this.dom.stats.textContent = (raw.length / 1024).toFixed(2) + ' KB';
        try {
            return raw ? JSON.parse(raw) : null;
        } catch(e) {
            this.dom.out.value = "Error: " + e.message;
            return null;
        }
    },

    process: function(act) {
        let d = this.parse();
        if(!d && act !== 'combine') return;

        try {
            if(act === 'prettify') this.dom.out.value = JSON.stringify(d, null, 2);
            if(act === 'minify') this.dom.out.value = JSON.stringify(d);
            if(act === 'sort') this.dom.out.value = JSON.stringify(this.sortKeys(d), null, 2);
            if(act === 'dedupe') {
                if(!Array.isArray(d)) throw "Requires Array";
                const u = [...new Set(d.map(i=>JSON.stringify(i)))].map(i=>JSON.parse(i));
                this.dom.out.value = JSON.stringify(u, null, 2);
            }
            if(act === 'combine') {
                this.dom.in.placeholder = "Click 'Load' button to select multiple files.";
                this.dom.in.value = "";
                alert("Please use the 'Load' button in the header to select multiple JSON files.");
            }
            this.setView('text');
        } catch(e) { this.dom.out.value = e; }
    },

    convert: function(fmt) {
        const d = this.parse();
        if(!d) return;
        let res = "";
        try {
            if(fmt === 'xml') res = this.toXML(d);
            if(fmt === 'csv') res = this.toCSV(d);
            if(fmt === 'toml') res = this.toTOML(d);
            this.dom.out.value = res;
            this.setView('text');
        } catch(e) { this.dom.out.value = "Convert Error: " + e.message; }
    },

    // Helpers
    sortKeys: function(o) {
        if(typeof o !== 'object' || o === null) return o;
        if(Array.isArray(o)) return o.map(this.sortKeys.bind(this));
        return Object.keys(o).sort().reduce((acc,k)=>{ acc[k]=this.sortKeys(o[k]); return acc;},{});
    },

    toXML: function(o) {
        let xml = "";
        for(let k in o) {
            if(o.hasOwnProperty(k)) {
                let v = o[k];
                if(Array.isArray(v)) v.forEach(i => xml += `<${k}>${typeof i=='object'?this.toXML(i):i}</${k}>`);
                else if(typeof v === 'object') xml += `<${k}>${this.toXML(v)}</${k}>`;
                else xml += `<${k}>${v}</${k}>`;
            }
        }
        return xml || "Empty";
    },

    toCSV: function(arr) {
        if(!Array.isArray(arr) || !arr.length) throw "Requires Array of Objects";
        const h = Object.keys(arr[0]);
        return [h.join(','), ...arr.map(r => h.map(k => JSON.stringify(r[k]||"")).join(','))].join('\n');
    },
    
    toTOML: function(obj) {
        // Simple TOML generator
        let out = "";
        const serialize = (o, p="") => {
            for(let k in o) {
                if(typeof o[k]!=='object') out += `${k} = ${JSON.stringify(o[k])}\n`;
            }
            for(let k in o) {
                if(typeof o[k]==='object' && !Array.isArray(o[k])) {
                    out += `\n[${p}${k}]\n`; serialize(o[k], p+k+".");
                }
            }
        };
        serialize(obj);
        return out;
    },

    // Visualizer
    setView: function(v) {
        this.dom.vis.style.display = v==='tree' ? 'block' : 'none';
        this.dom.out.style.display = v==='text' ? 'block' : 'none';
        if(v==='tree') {
            const d = this.parse();
            this.dom.vis.innerHTML = "";
            if(d) this.dom.vis.appendChild(this.buildTree(d));
        }
    },

    buildTree: function(o) {
        if(o === null) return this.span("null","jb");
        if(typeof o !== "object") return this.span(JSON.stringify(o), typeof o=='string'?'js':'jn');
        
        const root = document.createElement("div");
        const head = document.createElement("div");
        const isArr = Array.isArray(o);
        head.className = "collapsible";
        head.textContent = isArr ? `Array [${o.length}]` : `Object {${Object.keys(o).length}}`;
        head.onclick = function(){ this.classList.toggle("collapsed"); };
        
        const ul = document.createElement("ul");
        ul.className = "tree";
        
        for(let k in o) {
            const li = document.createElement("li");
            const keyS = document.createElement("span");
            keyS.className = "jk";
            keyS.textContent = isArr ? "" : k + ": ";
            li.appendChild(keyS);
            li.appendChild(this.buildTree(o[k]));
            ul.appendChild(li);
        }
        root.append(head, ul);
        return root;
    },
    span: function(t,c) { const s=document.createElement('span'); s.className=c; s.textContent=t; return s; },

    // Modals
    modal: function(id) { document.getElementById('m-'+id).style.display = 'flex'; },
    closeModals: function() { document.querySelectorAll('.json-modal').forEach(e=>e.style.display='none'); },

    // Advanced Ops
    execFilter: function() {
        const d = this.parse();
        const q = document.getElementById('filter-q').value;
        if(!Array.isArray(d)) return alert("Requires Array");
        try {
            const f = new Function('item', `return ${q}`);
            this.dom.out.value = JSON.stringify(d.filter(f), null, 2);
            this.closeModals();
        } catch(e) { alert("JS Error: "+e.message); }
    },

    execSplit: function() {
        if(typeof JSZip === 'undefined') return alert("JSZip library loading... try again in 2 seconds.");
        const d = this.parse();
        const n = parseInt(document.getElementById('split-count').value);
        if(!Array.isArray(d)) return alert("Requires Array");

        const zip = new JSZip();
        for(let i=0; i<d.length; i+=n) {
            zip.file(`part_${(i/n)+1}.json`, JSON.stringify(d.slice(i, i+n), null, 2));
        }
        zip.generateAsync({type:"blob"}).then(c => {
            const a = document.createElement("a");
            a.href = URL.createObjectURL(c);
            a.download = "json_split.zip";
            a.click();
            this.closeModals();
        });
    },

    download: function() {
        const b = new Blob([this.dom.out.value], {type:'text/plain'});
        const a = document.createElement('a');
        a.href = URL.createObjectURL(b);
        a.download = 'output.txt';
        a.click();
    }
};

// File Listener
document.getElementById('jsonFileLoad').addEventListener('change', async (e) => {
    const f = Array.from(e.target.files);
    if(!f.length) return;
    
    if(f.length === 1) {
        JsonApp.dom.in.value = await f[0].text();
        JsonApp.process('prettify');
    } else {
        // Combine Logic
        let all = [];
        let obj = {};
        let isObj = false;
        for(let file of f) {
            try {
                const j = JSON.parse(await file.text());
                if(Array.isArray(j)) all = all.concat(j);
                else { isObj = true; Object.assign(obj, j); }
            } catch(e){}
        }
        JsonApp.dom.in.value = JSON.stringify((isObj && !all.length) ? obj : all, null, 2);
    }
    JsonApp.parse(); // update stats
});